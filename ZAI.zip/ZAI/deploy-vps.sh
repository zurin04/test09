#!/bin/bash

# Crypto Airdrop Platform - Production VPS Deployment
# Optimized one-click deployment for Ubuntu VPS

set -e

echo "======================================"
echo "Crypto Airdrop Platform Deployment"
echo "======================================"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

print_status() { echo -e "${GREEN}[INFO]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[WARN]${NC} $1"; }
print_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Check prerequisites
[[ $EUID -eq 0 ]] && { print_error "Do not run as root. Use a regular user with sudo privileges."; exit 1; }
command -v sudo >/dev/null || { print_error "sudo is required but not installed."; exit 1; }

# Install system dependencies
print_status "Installing system dependencies..."
sudo apt update -y && sudo apt install -y curl wget gnupg postgresql postgresql-contrib nginx certbot python3-certbot-nginx python3 build-essential

# Install Node.js 20
if ! command -v node &>/dev/null; then
    print_status "Installing Node.js 20..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt install -y nodejs
fi

# Install PM2
sudo npm install -g pm2 2>/dev/null || print_warning "PM2 already installed"

# Start services
sudo systemctl enable --now postgresql nginx

# Setup application
APP_DIR="/var/www/crypto-airdrop"
print_status "Setting up application..."
sudo mkdir -p $APP_DIR && sudo chown $USER:$USER $APP_DIR
cp -r . $APP_DIR/ && cd $APP_DIR

# Generate secure credentials
DB_PASSWORD=$(openssl rand -base64 32)
SESSION_SECRET=$(openssl rand -hex 32)

# Create database and user
print_status "Setting up PostgreSQL database..."
sudo -u postgres psql << EOF
DROP DATABASE IF EXISTS crypto_airdrop_db;
DROP USER IF EXISTS crypto_airdrop_user;
CREATE USER crypto_airdrop_user WITH PASSWORD '$DB_PASSWORD' SUPERUSER;
CREATE DATABASE crypto_airdrop_db OWNER crypto_airdrop_user;
GRANT ALL PRIVILEGES ON DATABASE crypto_airdrop_db TO crypto_airdrop_user;
\q
EOF

# Create environment file
print_status "Creating environment configuration..."
cat > .env << ENV
DATABASE_URL=postgresql://crypto_airdrop_user:$DB_PASSWORD@localhost:5432/crypto_airdrop_db
SESSION_SECRET=$SESSION_SECRET
NODE_ENV=production
PORT=5000
PGHOST=localhost
PGPORT=5432
PGUSER=crypto_airdrop_user
PGPASSWORD=$DB_PASSWORD
PGDATABASE=crypto_airdrop_db
ENV

# Install dependencies 
print_status "Installing dependencies..."
npm install

# Setup database schema and seed data
print_status "Initializing database..."

# URL encode the password to handle special characters
if command -v python3 >/dev/null 2>&1; then
    DB_PASSWORD_ENCODED=$(python3 -c "import urllib.parse; print(urllib.parse.quote('$DB_PASSWORD', safe=''))")
else
    print_warning "Python3 not available, using password as-is (may cause issues with special characters)"
    DB_PASSWORD_ENCODED="$DB_PASSWORD"
fi
export DATABASE_URL="postgresql://crypto_airdrop_user:$DB_PASSWORD_ENCODED@localhost:5432/crypto_airdrop_db"
export SESSION_SECRET
export NODE_ENV=production

# Test database connection first
print_status "Testing database connection..."
if ! PGPASSWORD="$DB_PASSWORD" psql -h localhost -U crypto_airdrop_user -d crypto_airdrop_db -c "SELECT 1;" >/dev/null 2>&1; then
    print_error "Database connection failed. Check PostgreSQL setup."
    exit 1
fi

print_status "Pushing database schema..."
# Try with encoded URL first, then fallback to direct connection
if ! npm run db:push 2>&1; then
    print_warning "Schema push with encoded URL failed, trying direct connection..."
    # Try with raw password
    export DATABASE_URL="postgresql://crypto_airdrop_user:$DB_PASSWORD@localhost:5432/crypto_airdrop_db"
    if ! npm run db:push 2>&1; then
        print_error "Database schema push failed with both URL formats."
        exit 1
    fi
fi

print_status "Seeding database..."
if ! npm run db:seed 2>&1; then
    print_warning "Seeding with current URL failed, trying with raw password..."
    export DATABASE_URL="postgresql://crypto_airdrop_user:$DB_PASSWORD@localhost:5432/crypto_airdrop_db"
    if ! npm run db:seed 2>&1; then
        print_error "Database seeding failed with both URL formats."
        exit 1
    fi
fi

# Update .env file with working DATABASE_URL
print_status "Updating environment configuration with working database URL..."
cat > .env << ENV
DATABASE_URL=$DATABASE_URL
SESSION_SECRET=$SESSION_SECRET
NODE_ENV=production
PORT=5000
PGHOST=localhost
PGPORT=5432
PGUSER=crypto_airdrop_user
PGPASSWORD=$DB_PASSWORD
PGDATABASE=crypto_airdrop_db
ENV

# Build application with extended timeout and memory optimization
print_status "Building application..."
export NODE_OPTIONS="--max-old-space-size=4096"
timeout 600 npm run build || {
    print_warning "Build timed out or failed, trying fallback strategy..."
    # Fallback strategy for resource-constrained VPS
    export NODE_OPTIONS="--max-old-space-size=2048"
    timeout 300 npm run build || {
        print_error "Build failed even with fallback strategy. Check available memory and try building locally."
        exit 1
    }
}

# Configure PM2 and services
print_status "Configuring services..."
mkdir -p logs

# Determine which URL format worked
WORKING_DB_URL="$DATABASE_URL"

cat > ecosystem.config.cjs << EOF
module.exports = {
  apps: [{
    name: 'crypto-airdrop',
    script: 'npm',
    args: 'start',
    instances: 1,
    autorestart: true,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 5000,
      DATABASE_URL: '$WORKING_DB_URL',
      SESSION_SECRET: '$SESSION_SECRET',
      PGHOST: 'localhost',
      PGPORT: '5432',
      PGUSER: 'crypto_airdrop_user',
      PGPASSWORD: '$DB_PASSWORD',
      PGDATABASE: 'crypto_airdrop_db'
    },
    error_file: './logs/err.log',
    out_file: './logs/out.log',
    log_file: './logs/combined.log'
  }]
}
EOF

# Configure Nginx
sudo tee /etc/nginx/sites-available/crypto-airdrop > /dev/null << 'EOF'
server {
    listen 80;
    server_name _;
    client_max_body_size 100M;
    
    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
    
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";
    add_header Referrer-Policy "strict-origin-when-cross-origin";
}
EOF

sudo ln -sf /etc/nginx/sites-available/crypto-airdrop /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl reload nginx

# Seed database with required categories
print_status "Seeding database with categories..."
PGPASSWORD="$DB_PASSWORD" psql -h localhost -U crypto_airdrop_user -d crypto_airdrop << 'EOF'
-- Insert categories if they don't exist
INSERT INTO categories (id, name, description, created_at) 
SELECT 1, 'DeFi', 'Decentralized Finance protocols and platforms', NOW()
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE id = 1);

INSERT INTO categories (id, name, description, created_at) 
SELECT 2, 'NFT', 'Non-Fungible Token projects and marketplaces', NOW()
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE id = 2);

INSERT INTO categories (id, name, description, created_at) 
SELECT 3, 'Gaming', 'Blockchain gaming and GameFi projects', NOW()
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE id = 3);

INSERT INTO categories (id, name, description, created_at) 
SELECT 4, 'News', 'Latest news and announcements', NOW()
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE id = 4);

INSERT INTO categories (id, name, description, created_at) 
SELECT 5, 'Layer 1', 'Layer 1 blockchain platforms and protocols', NOW()
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE id = 5);

INSERT INTO categories (id, name, description, created_at) 
SELECT 6, 'Layer 2', 'Layer 2 scaling solutions and side chains', NOW()
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE id = 6);

-- Update sequence
SELECT setval('categories_id_seq', (SELECT MAX(id) FROM categories) + 1);
EOF

if [ $? -eq 0 ]; then
    print_status "Database seeded successfully"
else
    print_warning "Database seeding may have failed - continuing..."
fi

# Start application
print_status "Starting application with PM2..."
pm2 delete all 2>/dev/null || true
pm2 start ecosystem.config.cjs
pm2 save

# Setup PM2 startup
print_status "Configuring PM2 auto-startup..."
sudo env PATH=$PATH:/usr/bin /usr/lib/node_modules/pm2/bin/pm2 startup systemd -u $USER --hp $HOME

# Verify application is running
print_status "Verifying application startup..."
sleep 5
if pm2 list | grep -q "crypto-airdrop.*online"; then
    print_status "Application started successfully!"
else
    print_error "Application failed to start. Check logs with: pm2 logs crypto-airdrop"
    exit 1
fi

# Setup security and management
print_status "Finalizing setup..."
sudo ufw --force enable
sudo ufw allow 22,80,443/tcp

# Make verification script executable
chmod +x verify-deployment.sh

# Create enhanced management script
cat > manage.sh << 'SCRIPT'
#!/bin/bash

# Load environment variables
if [ -f .env ]; then
    export $(grep -v '^#' .env | xargs)
fi

BACKUP_DIR="/var/backups/crypto-airdrop"
APP_DIR="/var/www/crypto-airdrop"

backup_database() {
    mkdir -p $BACKUP_DIR
    BACKUP_FILE="$BACKUP_DIR/backup_$(date +%Y%m%d_%H%M%S).sql"
    echo "Creating database backup..."
    
    # Extract password from environment or DATABASE_URL
    if [ -z "$DB_PASSWORD" ]; then
        # Extract password from DATABASE_URL if DB_PASSWORD not set
        DB_PASSWORD=$(echo "$DATABASE_URL" | sed -n 's/.*:\/\/[^:]*:\([^@]*\)@.*/\1/p' | python3 -c "import urllib.parse, sys; print(urllib.parse.unquote(sys.stdin.read().strip()))")
    fi
    
    if PGPASSWORD="$DB_PASSWORD" pg_dump -h localhost -U crypto_airdrop_user crypto_airdrop_db > $BACKUP_FILE; then
        echo "✓ Backup saved to: $BACKUP_FILE"
        # Keep only last 7 backups
        ls -t $BACKUP_DIR/backup_*.sql | tail -n +8 | xargs -r rm
        echo "✓ Old backups cleaned up (keeping last 7)"
    else
        echo "✗ Backup failed!"
        exit 1
    fi
}

restore_database() {
    local backup_file=$2
    if [ -z "$backup_file" ]; then
        echo "Available backups:"
        ls -la $BACKUP_DIR/backup_*.sql 2>/dev/null || echo "No backups found"
        echo "Usage: $0 restore /path/to/backup.sql"
        exit 1
    fi
    
    if [ ! -f "$backup_file" ]; then
        echo "✗ Backup file not found: $backup_file"
        exit 1
    fi
    
    echo "⚠️  WARNING: This will replace all current data!"
    echo "Press Enter to continue or Ctrl+C to cancel..."
    read
    
    echo "Stopping application..."
    pm2 stop crypto-airdrop
    
    echo "Restoring database from: $backup_file"
    
    # Extract password from environment or DATABASE_URL
    if [ -z "$DB_PASSWORD" ]; then
        DB_PASSWORD=$(echo "$DATABASE_URL" | sed -n 's/.*:\/\/[^:]*:\([^@]*\)@.*/\1/p' | python3 -c "import urllib.parse, sys; print(urllib.parse.unquote(sys.stdin.read().strip()))")
    fi
    
    if PGPASSWORD="$DB_PASSWORD" psql -h localhost -U crypto_airdrop_user -d crypto_airdrop_db -c "DROP SCHEMA public CASCADE; CREATE SCHEMA public;" && \
       PGPASSWORD="$DB_PASSWORD" psql -h localhost -U crypto_airdrop_user crypto_airdrop_db < $backup_file; then
        echo "✓ Database restored successfully"
        pm2 start crypto-airdrop
        echo "✓ Application restarted"
    else
        echo "✗ Restore failed!"
        pm2 start crypto-airdrop
        exit 1
    fi
}

safe_update() {
    echo "Starting safe update process..."
    
    # Create pre-update backup
    echo "Creating pre-update backup..."
    backup_database
    
    # Stop application
    echo "Stopping application..."
    pm2 stop crypto-airdrop
    
    # Update code
    echo "Pulling latest changes..."
    if git pull; then
        echo "✓ Code updated"
    else
        echo "✗ Git pull failed!"
        pm2 start crypto-airdrop
        exit 1
    fi
    
    # Install dependencies
    echo "Installing dependencies..."
    if npm install; then
        echo "✓ Dependencies updated"
    else
        echo "✗ npm install failed!"
        pm2 start crypto-airdrop
        exit 1
    fi
    
    # Update database schema
    echo "Updating database schema..."
    if npm run db:push; then
        echo "✓ Database schema updated"
    else
        echo "✗ Database migration failed!"
        echo "Restoring from backup..."
        # Find the most recent backup
        LATEST_BACKUP=$(ls -t $BACKUP_DIR/backup_*.sql | head -1)
        restore_database restore $LATEST_BACKUP
        exit 1
    fi
    
    # Build application
    echo "Building application..."
    export NODE_OPTIONS="--max-old-space-size=4096"
    if timeout 600 npm run build; then
        echo "✓ Application built"
    else
        echo "✗ Build failed!"
        pm2 start crypto-airdrop
        exit 1
    fi
    
    # Start application
    echo "Starting application..."
    pm2 start crypto-airdrop
    
    # Verify application is running
    sleep 5
    if pm2 list | grep -q "crypto-airdrop.*online"; then
        echo "✓ Update completed successfully!"
    else
        echo "✗ Application failed to start after update!"
        echo "Check logs with: pm2 logs crypto-airdrop"
    fi
}

ssl_setup() {
    local domain=$2
    if [ -z "$domain" ]; then
        echo "Usage: $0 ssl yourdomain.com"
        exit 1
    fi
    
    echo "Setting up SSL for domain: $domain"
    
    # Update Nginx config
    sudo sed -i "s/server_name _;/server_name $domain;/" /etc/nginx/sites-available/crypto-airdrop
    sudo nginx -t && sudo systemctl reload nginx
    
    # Get SSL certificate
    if sudo certbot --nginx -d "$domain" --non-interactive --agree-tos --email "admin@$domain" --redirect; then
        echo "✓ SSL certificate installed successfully!"
        # Setup automatic renewal
        (sudo crontab -l 2>/dev/null | grep -v "certbot renew"; echo "0 12 * * * /usr/bin/certbot renew --quiet") | sudo crontab -
        echo "✓ Automatic renewal configured"
    else
        echo "✗ SSL certificate installation failed. Check DNS configuration."
        exit 1
    fi
}

health_check() {
    echo "Crypto Airdrop Platform - Health Check"
    echo "====================================="
    
    # Check application status
    if pm2 list | grep -q "crypto-airdrop.*online"; then
        echo "✓ Application: Running"
    else
        echo "✗ Application: Not running"
    fi
    
    # Check database
    if systemctl is-active --quiet postgresql; then
        echo "✓ PostgreSQL: Running"
        # Test database connection
        if [ -z "$DB_PASSWORD" ]; then
            DB_PASSWORD=$(echo "$DATABASE_URL" | sed -n 's/.*:\/\/[^:]*:\([^@]*\)@.*/\1/p' | python3 -c "import urllib.parse, sys; print(urllib.parse.unquote(sys.stdin.read().strip()))")
        fi
        if PGPASSWORD="$DB_PASSWORD" psql -h localhost -U crypto_airdrop_user -d crypto_airdrop_db -c "SELECT 1;" >/dev/null 2>&1; then
            echo "✓ Database: Connected"
        else
            echo "✗ Database: Connection failed"
        fi
    else
        echo "✗ PostgreSQL: Not running"
    fi
    
    # Check web server
    if systemctl is-active --quiet nginx; then
        echo "✓ Nginx: Running"
        # Test web server response
        if curl -s -o /dev/null -w "%{http_code}" http://localhost | grep -q "200"; then
            echo "✓ Web Server: Responding"
        else
            echo "✗ Web Server: Not responding"
        fi
    else
        echo "✗ Nginx: Not running"
    fi
    
    # Check disk space
    DISK_USAGE=$(df -h / | awk 'NR==2 {print $5}' | sed 's/%//')
    if [ "$DISK_USAGE" -lt 80 ]; then
        echo "✓ Disk Space: ${DISK_USAGE}% used"
    else
        echo "⚠ Disk Space: ${DISK_USAGE}% used (consider cleanup)"
    fi
    
    # Check memory usage
    MEMORY_USAGE=$(free | awk 'NR==2{printf "%.1f", $3*100/$2 }')
    echo "ℹ Memory Usage: ${MEMORY_USAGE}%"
    
    # Show recent logs
    echo ""
    echo "Recent Application Logs:"
    echo "------------------------"
    pm2 logs crypto-airdrop --lines 5 --nostream
}

case "$1" in
    start|stop|restart) 
        pm2 $1 crypto-airdrop 
        ;;
    status) 
        pm2 status && echo "" && pm2 logs crypto-airdrop --lines 10 --nostream
        ;;
    logs) 
        pm2 logs crypto-airdrop 
        ;;
    update) 
        safe_update 
        ;;
    backup) 
        backup_database 
        ;;
    restore) 
        restore_database $@ 
        ;;
    ssl) 
        ssl_setup $@ 
        ;;
    health) 
        health_check 
        ;;
    *) 
        echo "Crypto Airdrop Platform - Management Script"
        echo "==========================================="
        echo "Usage: $0 {command} [options]"
        echo ""
        echo "Commands:"
        echo "  start          - Start the application"
        echo "  stop           - Stop the application"
        echo "  restart        - Restart the application"
        echo "  status         - Show application status and recent logs"
        echo "  logs           - Show real-time logs"
        echo "  update         - Safe update (backup, pull, build, restart)"
        echo "  backup         - Create database backup"
        echo "  restore        - Restore from backup"
        echo "  ssl            - Setup SSL certificate for domain"
        echo "  health         - Comprehensive health check"
        echo ""
        echo "Examples:"
        echo "  $0 status"
        echo "  $0 backup"
        echo "  $0 ssl yourdomain.com"
        echo "  $0 restore /var/backups/crypto-airdrop/backup_20231227_120000.sql"
        ;;
esac
SCRIPT

chmod +x manage.sh

# Get server IP for display
SERVER_IP=$(curl -s ifconfig.me 2>/dev/null || hostname -I | awk '{print $1}' || echo "localhost")

# Display deployment completion info
print_status "Deployment completed successfully!"
echo ""
echo "======================================"
echo "DEPLOYMENT COMPLETED SUCCESSFULLY!"
echo "======================================"
echo ""
echo "🚀 Your Crypto Airdrop Platform is now live!"
echo ""
echo "Access your application:"
echo "   🌐 http://${SERVER_IP}"
echo ""
echo "Management commands:"
echo "   📊 cd $APP_DIR && ./manage.sh status    # Check status"
echo "   📝 cd $APP_DIR && ./manage.sh logs      # View logs" 
echo "   🔄 cd $APP_DIR && ./manage.sh restart   # Restart app"
echo "   🏥 cd $APP_DIR && ./manage.sh health    # Health check"
echo "   💾 cd $APP_DIR && ./manage.sh backup    # Create backup"
echo ""
echo "Service status:"
if systemctl is-active --quiet postgresql; then
    echo "   ✅ PostgreSQL"
else
    echo "   ❌ PostgreSQL"
fi

if systemctl is-active --quiet nginx; then
    echo "   ✅ Nginx (Port 80)"
else
    echo "   ❌ Nginx (Port 80)"
fi

if pm2 list | grep -q "crypto-airdrop.*online"; then
    echo "   ✅ Application (Port 5000)"
else
    echo "   ❌ Application (Port 5000)"
fi
echo ""
echo "Next steps:"
echo "   1. Test your application: curl -I http://${SERVER_IP}"
echo "   2. Set up SSL with: ./manage.sh ssl yourdomain.com"
echo "   3. Configure your domain name (if applicable)"
echo "   4. Review and update default admin credentials"
echo ""
echo "Default Admin Credentials:"
echo "   Username: admin"
echo "   Password: admin123"
echo "   ⚠️  Change these immediately after first login!"
echo ""
echo "Running deployment verification..."
if [ -f "verify-deployment.sh" ]; then
    ./verify-deployment.sh
else
    print_warning "Verification script not found, manual testing recommended"
fi