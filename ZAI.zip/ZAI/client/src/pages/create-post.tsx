import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { RichTextEditor } from "@/components/ui/rich-text-editor";
import { Loader2, Plus, X, PlusCircle, Megaphone, BookOpen } from "lucide-react";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import type { InsertAirdrops, Category } from "@shared/schema";
import Sidebar from "@/components/layout/sidebar";
import Header from "@/components/layout/header";

export default function CreatePostPage() {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  
  // State for form data
  const [formData, setFormData] = useState<Partial<InsertAirdrops> & { image?: File }>({
    title: "",
    description: "",
    tags: [] as string[],
    link: "",
    potential_profit: "",
    status: "active",
    category_id: undefined,
    post_type: "airdrop_steps",
    is_banner: false,
  });
  
  const [currentTag, setCurrentTag] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  
  // Fetch categories
  const { data: categories, isLoading: categoriesLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });
  
  // Create post mutation
  const createPostMutation = useMutation({
    mutationFn: async (data: { formData: Partial<InsertAirdrops>; image?: File }) => {
      if (data.image) {
        const formData = new FormData();
        Object.entries(data.formData).forEach(([key, value]) => {
          if (value !== undefined && value !== null) {
            if (key === 'tags' && Array.isArray(value)) {
              formData.append(key, JSON.stringify(value));
            } else {
              formData.append(key, String(value));
            }
          }
        });
        formData.append('image', data.image);
        
        const res = await fetch('/api/airdrops', {
          method: 'POST',
          body: formData,
          credentials: 'include'
        });
        
        if (!res.ok) {
          const errorData = await res.json();
          throw new Error(errorData.message || "Failed to create post");
        }
        return res.json();
      } else {
        const res = await apiRequest("POST", "/api/airdrops", data.formData);
        return await res.json();
      }
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/airdrops"] });
      queryClient.invalidateQueries({ queryKey: ["/api/airdrops/featured"] });
      queryClient.invalidateQueries({ queryKey: ["/api/airdrops/announcements"] });
      queryClient.invalidateQueries({ queryKey: ["/api/airdrops/banner"] });
      
      const postTypeLabel = formData.post_type === 'announcement' ? 'announcement' : 'airdrop tutorial';
      toast({
        title: `${postTypeLabel} created successfully`,
        description: `Your ${postTypeLabel} has been published.`,
      });
      
      // Navigate based on post type
      if (formData.post_type === 'announcement') {
        navigate("/announcements");
      } else {
        navigate("/airdrops");
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Error creating post",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Check user permissions
  useEffect(() => {
    if (user && !user.isCreator && !user.isAdmin) {
      toast({
        title: "Access Required",
        description: "You need creator or admin privileges to create posts.",
        variant: "destructive",
      });
      navigate("/");
    }
  }, [user, navigate, toast]);
  
  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.title?.trim()) {
      newErrors.title = "Title is required";
    }
    
    if (!formData.description?.trim()) {
      newErrors.description = "Content is required";
    }
    
    if (!formData.category_id) {
      newErrors.category_id = "Category is required";
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      createPostMutation.mutate({ formData, image: formData.image });
    }
  };
  
  const addTag = () => {
    if (currentTag.trim() && !(formData.tags || []).includes(currentTag.trim())) {
      setFormData({
        ...formData,
        tags: [...(formData.tags || []), currentTag.trim()],
      });
      setCurrentTag("");
    }
  };
  
  const removeTag = (tagToRemove: string) => {
    const currentTags = formData.tags || [];
    const filteredTags = currentTags.filter((tag: any) => tag !== tagToRemove);
    setFormData({
      ...formData,
      tags: filteredTags,
    });
  };
  
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFormData({ ...formData, image: file });
    }
  };
  
  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }
  
  return (
    <>
      <Header />
      <div className="flex min-h-screen bg-gray-50 dark:bg-gray-900">
        <Sidebar />
        
        <main className="md:ml-64 flex-1 p-6 md:p-10">
          <div className="max-w-4xl mx-auto">
            <div className="mb-8">
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">Create New Post</h1>
              <p className="text-gray-600 dark:text-gray-400">
                {user.isAdmin ? "Create airdrop tutorials, news, or announcements" : "Create airdrop tutorials for the community"}
              </p>
            </div>
            
            {/* Role-based Post Type Selection */}
            <div className="mb-8">
              <Tabs 
                value={formData.post_type} 
                onValueChange={(value) => setFormData({ ...formData, post_type: value as any })}
              >
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="airdrop_steps" className="flex items-center gap-2">
                    <BookOpen className="h-4 w-4" />
                    Airdrop Tutorial
                  </TabsTrigger>
                  {user.isAdmin && (
                    <TabsTrigger value="announcement" className="flex items-center gap-2">
                      <Megaphone className="h-4 w-4" />
                      News/Announcement
                    </TabsTrigger>
                  )}
                </TabsList>
                
                <TabsContent value="airdrop_steps" className="mt-6">
                  <Card className="border-2 border-blue-200 dark:border-blue-800">
                    <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20">
                      <CardTitle className="text-blue-800 dark:text-blue-200 flex items-center gap-2">
                        <BookOpen className="h-5 w-5" />
                        Airdrop Tutorial
                      </CardTitle>
                      <CardDescription>
                        Create step-by-step instructions for participating in cryptocurrency airdrops
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="p-6">
                      <PostForm
                        formData={formData}
                        setFormData={setFormData}
                        errors={errors}
                        categories={categories}
                        categoriesLoading={categoriesLoading}
                        currentTag={currentTag}
                        setCurrentTag={setCurrentTag}
                        addTag={addTag}
                        removeTag={removeTag}
                        handleImageChange={handleImageChange}
                        handleSubmit={handleSubmit}
                        createPostMutation={createPostMutation}
                        navigate={navigate}
                        postType="airdrop_steps"
                      />
                    </CardContent>
                  </Card>
                </TabsContent>
                
                {user.isAdmin && (
                  <TabsContent value="announcement" className="mt-6">
                    <Card className="border-2 border-orange-200 dark:border-orange-800">
                      <CardHeader className="bg-gradient-to-r from-orange-50 to-amber-50 dark:from-orange-900/20 dark:to-amber-900/20">
                        <CardTitle className="text-orange-800 dark:text-orange-200 flex items-center gap-2">
                          <Megaphone className="h-5 w-5" />
                          News & Announcement
                        </CardTitle>
                        <CardDescription>
                          Share important news, updates, and announcements with the community
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="p-6">
                        <PostForm
                          formData={formData}
                          setFormData={setFormData}
                          errors={errors}
                          categories={categories}
                          categoriesLoading={categoriesLoading}
                          currentTag={currentTag}
                          setCurrentTag={setCurrentTag}
                          addTag={addTag}
                          removeTag={removeTag}
                          handleImageChange={handleImageChange}
                          handleSubmit={handleSubmit}
                          createPostMutation={createPostMutation}
                          navigate={navigate}
                          postType="announcement"
                        />
                      </CardContent>
                    </Card>
                  </TabsContent>
                )}
              </Tabs>
            </div>
          </div>
        </main>
      </div>
    </>
  );
}

// Shared form component
interface PostFormProps {
  formData: Partial<InsertAirdrops> & { image?: File };
  setFormData: (data: Partial<InsertAirdrops> & { image?: File }) => void;
  errors: Record<string, string>;
  categories: Category[] | undefined;
  categoriesLoading: boolean;
  currentTag: string;
  setCurrentTag: (tag: string) => void;
  addTag: () => void;
  removeTag: (tag: string) => void;
  handleImageChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  handleSubmit: (e: React.FormEvent) => void;
  createPostMutation: any;
  navigate: (path: string) => void;
  postType: string;
}

function PostForm({
  formData,
  setFormData,
  errors,
  categories,
  categoriesLoading,
  currentTag,
  setCurrentTag,
  addTag,
  removeTag,
  handleImageChange,
  handleSubmit,
  createPostMutation,
  navigate,
  postType
}: PostFormProps) {
  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Title */}
      <div>
        <Label htmlFor="title" className="text-base font-medium">Title *</Label>
        <Input
          id="title"
          value={formData.title || ""}
          onChange={(e) => setFormData({ ...formData, title: e.target.value })}
          placeholder={postType === 'announcement' ? "Enter news title..." : "Enter airdrop title..."}
          className={errors.title ? "border-red-500" : ""}
        />
        {errors.title && <p className="text-red-500 text-sm mt-1">{errors.title}</p>}
      </div>
      
      {/* Content */}
      <div>
        <Label className="text-base font-medium">Content *</Label>
        <RichTextEditor
          value={formData.description || ""}
          onChange={(value) => setFormData({ ...formData, description: value })}
          placeholder={postType === 'announcement' ? "Write your announcement..." : "Write step-by-step instructions..."}
        />
        {errors.description && <p className="text-red-500 text-sm mt-1">{errors.description}</p>}
      </div>
      
      {/* Tags */}
      <div>
        <Label className="text-base font-medium">Tags</Label>
        <div className="flex space-x-2 mb-2">
          <Input
            value={currentTag}
            onChange={(e) => setCurrentTag(e.target.value)}
            placeholder="Add a tag"
            className="flex-1"
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                addTag();
              }
            }}
          />
          <Button type="button" onClick={addTag} variant="outline">
            <Plus className="h-4 w-4" />
          </Button>
        </div>
        <div className="flex flex-wrap gap-2">
          {(formData.tags || []).map((tag: string, index: number) => (
            <Badge key={index} variant="secondary" className="flex items-center gap-1">
              {tag}
              <button type="button" onClick={() => removeTag(tag)}>
                <X className="h-3 w-3" />
              </button>
            </Badge>
          ))}
        </div>
      </div>
      
      {/* Category */}
      <div>
        <Label htmlFor="category" className="text-base font-medium">Category *</Label>
        <Select 
          value={formData.category_id?.toString()} 
          onValueChange={(value) => setFormData({ ...formData, category_id: parseInt(value, 10) })}
        >
          <SelectTrigger id="category" className={errors.category_id ? "border-red-500" : ""}>
            <SelectValue placeholder="Select a category" />
          </SelectTrigger>
          <SelectContent>
            {categoriesLoading ? (
              <div className="flex items-center justify-center p-2">
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
                Loading categories...
              </div>
            ) : (
              categories?.map((category) => (
                <SelectItem key={category.id} value={category.id.toString()}>
                  {category.name}
                </SelectItem>
              ))
            )}
          </SelectContent>
        </Select>
        {errors.category_id && <p className="text-red-500 text-sm mt-1">{errors.category_id}</p>}
      </div>
      
      {/* Optional fields based on post type */}
      {postType === 'airdrop_steps' && (
        <>
          <div>
            <Label htmlFor="link" className="text-base font-medium">Airdrop Link</Label>
            <Input
              id="link"
              value={formData.link || ""}
              onChange={(e) => setFormData({ ...formData, link: e.target.value })}
              placeholder="https://example.com/airdrop"
            />
          </div>
          
          <div>
            <Label htmlFor="potential_profit" className="text-base font-medium">Potential Profit</Label>
            <Input
              id="potential_profit"
              value={formData.potential_profit || ""}
              onChange={(e) => setFormData({ ...formData, potential_profit: e.target.value })}
              placeholder="e.g., $10-50"
            />
          </div>
        </>
      )}
      
      {/* Image upload */}
      <div>
        <Label htmlFor="image" className="text-base font-medium">Image (Optional)</Label>
        <Input
          id="image"
          type="file"
          accept="image/*"
          onChange={handleImageChange}
          className="file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
        />
        <p className="text-sm text-gray-500 mt-1">Upload an image to make your post more engaging</p>
      </div>
      
      {/* Banner option for announcements */}
      {postType === 'announcement' && (
        <div className="flex items-center space-x-2">
          <Checkbox
            id="is_banner"
            checked={formData.is_banner || false}
            onCheckedChange={(checked) => setFormData({ ...formData, is_banner: !!checked })}
          />
          <Label htmlFor="is_banner" className="text-sm">
            Display as banner announcement (appears prominently at top of site)
          </Label>
        </div>
      )}
      
      {/* Submit buttons */}
      <div className="flex justify-between pt-4">
        <Button 
          type="button" 
          variant="outline" 
          onClick={() => navigate("/airdrops")}
        >
          Cancel
        </Button>
        <Button 
          type="submit" 
          disabled={createPostMutation.isPending}
          className={postType === 'announcement' ? "bg-orange-600 hover:bg-orange-700" : "bg-blue-600 hover:bg-blue-700"}
        >
          {createPostMutation.isPending ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Publishing...
            </>
          ) : (
            <>
              <PlusCircle className="mr-2 h-4 w-4" />
              Publish {postType === 'announcement' ? 'News' : 'Tutorial'}
            </>
          )}
        </Button>
      </div>
    </form>
  );
}