import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { Helmet } from "react-helmet";
import CategoryManagement from "@/components/admin/category-management";
import SiteSettings from "@/components/admin/site-settings";
import AirdropManagement from "@/components/admin/airdrop-management";
import UserManagement from "@/components/admin/user-management";
import NewsletterManagement from "@/components/admin/newsletter-management";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, Settings, Layers, ListChecks, Users, MailIcon, TrendingUp, Eye, UserPlus, MessageSquare } from "lucide-react";
import { Redirect } from "wouter";
import { Airdrops, User as UserType, Newsletter } from "@shared/schema";

function AdminDashboard() {
  const { user, isLoading } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("overview");

  // Fetch dashboard statistics
  const { data: airdrops = [] } = useQuery<Airdrops[]>({
    queryKey: ["/api/airdrops"],
  });

  const { data: users = [] } = useQuery<UserType[]>({
    queryKey: ["/api/admin/users"],
  });

  const { data: newsletters = [] } = useQuery<Newsletter[]>({
    queryKey: ["/api/admin/newsletter-subscribers"],
  });

  // Calculate statistics
  const totalAirdrops = airdrops.length;
  const activeAirdrops = airdrops.filter(a => a.status === 'active').length;
  const totalViews = airdrops.reduce((sum, a) => sum + (a.views || 0), 0);
  const totalUsers = users.length;
  const adminUsers = users.filter(u => u.isAdmin).length;
  const creatorUsers = users.filter(u => u.isCreator).length;
  const newsletterSubscribers = newsletters.length;
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-10 w-10 animate-spin text-primary" />
      </div>
    );
  }
  
  if (!user) {
    return <Redirect to="/auth" />;
  }
  
  if (!user.isAdmin) {
    return (
      <div className="container max-w-4xl mx-auto py-16 px-4">
        <Card>
          <CardHeader>
            <CardTitle>Access Denied</CardTitle>
            <CardDescription>
              You do not have permission to access the admin dashboard.
            </CardDescription>
          </CardHeader>
          <CardFooter>
            <Button onClick={() => window.location.href = "/"}>
              Return to Home
            </Button>
          </CardFooter>
        </Card>
      </div>
    );
  }
  
  return (
    <div className="container max-w-6xl mx-auto py-8 px-4">
      <Helmet>
        <title>Admin Dashboard - Crypto Airdrop Task Hub</title>
      </Helmet>
      
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Admin Dashboard
          </h1>
          <p className="text-muted-foreground">Manage your site content and settings</p>
        </div>
        <Badge variant="outline" className="border-blue-500 text-blue-400">
          <span className="mr-1">⚡</span>
          Admin Panel
        </Badge>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-6 mb-8">
          <TabsTrigger value="overview" className="flex items-center">
            <TrendingUp className="h-4 w-4 mr-2" />
            <span className="hidden sm:inline">Overview</span>
          </TabsTrigger>
          <TabsTrigger value="airdrops" className="flex items-center">
            <ListChecks className="h-4 w-4 mr-2" />
            <span className="hidden sm:inline">Airdrops</span>
          </TabsTrigger>
          <TabsTrigger value="categories" className="flex items-center">
            <Layers className="h-4 w-4 mr-2" />
            <span className="hidden sm:inline">Categories</span>
          </TabsTrigger>
          <TabsTrigger value="users" className="flex items-center">
            <Users className="h-4 w-4 mr-2" />
            <span className="hidden sm:inline">Users</span>
          </TabsTrigger>
          <TabsTrigger value="newsletter" className="flex items-center">
            <MailIcon className="h-4 w-4 mr-2" />
            <span className="hidden sm:inline">Newsletter</span>
          </TabsTrigger>
          <TabsTrigger value="settings" className="flex items-center">
            <Settings className="h-4 w-4 mr-2" />
            <span className="hidden sm:inline">Site Settings</span>
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview" className="space-y-6">
          {/* Statistics Overview Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="relative overflow-hidden border-l-4 border-l-blue-500">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Total Airdrops</CardTitle>
                  <ListChecks className="h-4 w-4 text-blue-500" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{totalAirdrops}</div>
                <p className="text-xs text-muted-foreground">
                  {activeAirdrops} active
                </p>
              </CardContent>
            </Card>

            <Card className="relative overflow-hidden border-l-4 border-l-green-500">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Total Views</CardTitle>
                  <Eye className="h-4 w-4 text-green-500" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{totalViews.toLocaleString()}</div>
                <p className="text-xs text-muted-foreground">
                  All time views
                </p>
              </CardContent>
            </Card>

            <Card className="relative overflow-hidden border-l-4 border-l-purple-500">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Total Users</CardTitle>
                  <Users className="h-4 w-4 text-purple-500" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{totalUsers}</div>
                <p className="text-xs text-muted-foreground">
                  {creatorUsers} creators, {adminUsers} admins
                </p>
              </CardContent>
            </Card>

            <Card className="relative overflow-hidden border-l-4 border-l-orange-500">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Newsletter</CardTitle>
                  <MailIcon className="h-4 w-4 text-orange-500" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{newsletterSubscribers}</div>
                <p className="text-xs text-muted-foreground">
                  Subscribers
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="hover:shadow-lg transition-shadow cursor-pointer group">
              <CardHeader>
                <CardTitle className="flex items-center text-lg">
                  <ListChecks className="h-5 w-5 mr-2 text-blue-500" />
                  Manage Airdrops
                </CardTitle>
                <CardDescription>
                  Create, edit, and manage airdrop listings
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button 
                  variant="outline" 
                  className="w-full group-hover:bg-blue-50 group-hover:border-blue-300"
                  onClick={() => setActiveTab("airdrops")}
                >
                  Go to Airdrops
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow cursor-pointer group">
              <CardHeader>
                <CardTitle className="flex items-center text-lg">
                  <Users className="h-5 w-5 mr-2 text-purple-500" />
                  User Management
                </CardTitle>
                <CardDescription>
                  Manage users, roles, and permissions
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button 
                  variant="outline" 
                  className="w-full group-hover:bg-purple-50 group-hover:border-purple-300"
                  onClick={() => setActiveTab("users")}
                >
                  Manage Users
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow cursor-pointer group">
              <CardHeader>
                <CardTitle className="flex items-center text-lg">
                  <Settings className="h-5 w-5 mr-2 text-green-500" />
                  Site Settings
                </CardTitle>
                <CardDescription>
                  Configure site settings and appearance
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button 
                  variant="outline" 
                  className="w-full group-hover:bg-green-50 group-hover:border-green-300"
                  onClick={() => setActiveTab("settings")}
                >
                  Open Settings
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="airdrops" className="space-y-4">
          <AirdropManagement />
        </TabsContent>
        
        <TabsContent value="categories" className="space-y-4">
          <CategoryManagement />
        </TabsContent>
        
        <TabsContent value="users" className="space-y-4">
          <UserManagement />
        </TabsContent>
        
        <TabsContent value="newsletter" className="space-y-4">
          <NewsletterManagement />
        </TabsContent>
        
        <TabsContent value="settings" className="space-y-4">
          <SiteSettings />
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default function AdminDashboardPage() {
  return <AdminDashboard />;
}