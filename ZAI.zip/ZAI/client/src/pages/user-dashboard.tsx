import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import SidebarLayout from "@/components/layout/sidebar-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Link } from "wouter";
import { Airdrops } from "@shared/schema";
import { 
  BookmarkIcon, 
  CheckCircle2, 
  TrendingUp, 
  Eye, 
  Calendar,
  Trophy,
  Target,
  Star,
  Bell,
  Activity
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface UserStats {
  savedCount: number;
  completedCount: number;
  totalViews: number;
  totalPotentialProfit: number;
  completionRate: number;
  streakDays: number;
  level: number;
  xp: number;
  nextLevelXp: number;
}

interface AirdropWithStatus extends Airdrops {
  isSaved: boolean;
  isCompleted: boolean;
  completedAt?: string;
}

export default function UserDashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("overview");

  // Fetch user stats
  const { data: userStats, isLoading: statsLoading } = useQuery<UserStats>({
    queryKey: ["/api/user/stats"],
    enabled: !!user,
  });

  // Fetch saved airdrops
  const { data: savedAirdrops = [], isLoading: savedLoading } = useQuery<AirdropWithStatus[]>({
    queryKey: ["/api/user/saved-airdrops"],
    enabled: !!user,
  });

  // Fetch completed airdrops
  const { data: completedAirdrops = [], isLoading: completedLoading } = useQuery<AirdropWithStatus[]>({
    queryKey: ["/api/user/completed-airdrops"],
    enabled: !!user,
  });

  // Fetch recommended airdrops
  const { data: recommendedAirdrops = [], isLoading: recommendedLoading } = useQuery<Airdrops[]>({
    queryKey: ["/api/user/recommended-airdrops"],
    enabled: !!user,
  });

  // Toggle saved status
  const toggleSavedMutation = useMutation({
    mutationFn: async (airdropId: number) => {
      const response = await fetch(`/api/airdrops/${airdropId}/toggle-saved`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });
      if (!response.ok) throw new Error("Failed to toggle saved status");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/saved-airdrops"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user/stats"] });
      toast({
        title: "Updated",
        description: "Airdrop status updated successfully",
      });
    },
  });

  // Toggle completed status
  const toggleCompletedMutation = useMutation({
    mutationFn: async (airdropId: number) => {
      const response = await fetch(`/api/airdrops/${airdropId}/toggle-completed`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });
      if (!response.ok) throw new Error("Failed to toggle completed status");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/completed-airdrops"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user/stats"] });
      toast({
        title: "Updated",
        description: "Completion status updated successfully",
      });
    },
  });

  const getUserLevel = (xp: number) => {
    return Math.floor(xp / 1000) + 1;
  };

  const getXpForNextLevel = (level: number) => {
    return level * 1000;
  };

  const getLevelProgress = (xp: number, level: number) => {
    const currentLevelXp = (level - 1) * 1000;
    const nextLevelXp = level * 1000;
    return ((xp - currentLevelXp) / (nextLevelXp - currentLevelXp)) * 100;
  };

  if (!user) {
    return (
      <SidebarLayout title="User Dashboard">
        <div className="flex items-center justify-center h-64">
          <p className="text-muted-foreground">Please log in to view your dashboard.</p>
        </div>
      </SidebarLayout>
    );
  }

  return (
    <SidebarLayout title="My Dashboard - Crypto Airdrop Task Hub">
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Welcome back, {user.username}!</h1>
            <p className="text-muted-foreground mt-1">Track your progress and discover new opportunities</p>
          </div>
          <div className="flex items-center space-x-2">
            <Badge variant="secondary" className="text-sm">
              Level {userStats?.level || 1}
            </Badge>
            <Trophy className="h-5 w-5 text-yellow-500" />
          </div>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <BookmarkIcon className="h-4 w-4 text-blue-500" />
                <span className="text-sm font-medium">Saved</span>
              </div>
              <p className="text-2xl font-bold">{userStats?.savedCount || 0}</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <CheckCircle2 className="h-4 w-4 text-green-500" />
                <span className="text-sm font-medium">Completed</span>
              </div>
              <p className="text-2xl font-bold">{userStats?.completedCount || 0}</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <TrendingUp className="h-4 w-4 text-purple-500" />
                <span className="text-sm font-medium">Est. Profit</span>
              </div>
              <p className="text-2xl font-bold">${userStats?.totalPotentialProfit || 0}</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Target className="h-4 w-4 text-orange-500" />
                <span className="text-sm font-medium">Success Rate</span>
              </div>
              <p className="text-2xl font-bold">{userStats?.completionRate || 0}%</p>
            </CardContent>
          </Card>
        </div>

        {/* Level Progress */}
        {userStats && (
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-lg font-semibold">Level Progress</h3>
                  <p className="text-sm text-muted-foreground">
                    {userStats.xp} / {getXpForNextLevel(userStats.level)} XP
                  </p>
                </div>
                <Badge variant="outline" className="text-lg px-3 py-1">
                  Level {userStats.level}
                </Badge>
              </div>
              <Progress 
                value={getLevelProgress(userStats.xp, userStats.level)} 
                className="h-3"
              />
              <p className="text-xs text-muted-foreground mt-2">
                {getXpForNextLevel(userStats.level) - userStats.xp} XP until next level
              </p>
            </CardContent>
          </Card>
        )}

        {/* Main Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="saved">Saved ({savedAirdrops.length})</TabsTrigger>
            <TabsTrigger value="completed">Completed ({completedAirdrops.length})</TabsTrigger>
            <TabsTrigger value="recommended">Recommended</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Activity className="h-5 w-5" />
                  <span>Recent Activity</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {completedAirdrops.slice(0, 3).map((airdrop) => (
                    <div key={airdrop.id} className="flex items-center space-x-3 p-3 bg-muted/50 rounded-lg">
                      <CheckCircle2 className="h-4 w-4 text-green-500" />
                      <div className="flex-1">
                        <p className="font-medium">{airdrop.title}</p>
                        <p className="text-sm text-muted-foreground">
                          Completed {airdrop.completedAt ? new Date(airdrop.completedAt).toLocaleDateString() : 'recently'}
                        </p>
                      </div>
                    </div>
                  ))}
                  {completedAirdrops.length === 0 && (
                    <p className="text-center text-muted-foreground py-4">
                      No completed airdrops yet. Start exploring!
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <Link to="/airdrops">
                    <Button variant="outline" className="w-full h-20 flex-col space-y-2">
                      <Eye className="h-5 w-5" />
                      <span>Browse Airdrops</span>
                    </Button>
                  </Link>
                  <Link to="/create-airdrop">
                    <Button variant="outline" className="w-full h-20 flex-col space-y-2">
                      <Star className="h-5 w-5" />
                      <span>Create Post</span>
                    </Button>
                  </Link>
                  <Link to="/profile">
                    <Button variant="outline" className="w-full h-20 flex-col space-y-2">
                      <Trophy className="h-5 w-5" />
                      <span>View Profile</span>
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="saved" className="space-y-4">
            {savedLoading ? (
              <div className="text-center py-8">Loading saved airdrops...</div>
            ) : savedAirdrops.length > 0 ? (
              <div className="grid gap-4">
                {savedAirdrops.map((airdrop) => (
                  <Card key={airdrop.id} className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <Link to={`/airdrop/${airdrop.id}`}>
                          <h3 className="font-semibold hover:text-primary cursor-pointer">
                            {airdrop.title}
                          </h3>
                        </Link>
                        <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                          {airdrop.description}
                        </p>
                        <div className="flex items-center space-x-4 mt-3">
                          <Badge variant={airdrop.status === 'active' ? 'default' : 'secondary'}>
                            {airdrop.status}
                          </Badge>
                          {airdrop.potential_profit && (
                            <span className="text-sm text-green-600 font-medium">
                              {airdrop.potential_profit}
                            </span>
                          )}
                          <span className="text-xs text-muted-foreground flex items-center">
                            <Eye className="h-3 w-3 mr-1" />
                            {airdrop.views || 0}
                          </span>
                        </div>
                      </div>
                      <div className="flex space-x-2 ml-4">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => toggleSavedMutation.mutate(airdrop.id)}
                          disabled={toggleSavedMutation.isPending}
                        >
                          <BookmarkIcon className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => toggleCompletedMutation.mutate(airdrop.id)}
                          disabled={toggleCompletedMutation.isPending}
                        >
                          <CheckCircle2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="text-center py-8">
                  <BookmarkIcon className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No saved airdrops yet</h3>
                  <p className="text-muted-foreground mb-4">
                    Start saving airdrops you're interested in to track them here.
                  </p>
                  <Link to="/airdrops">
                    <Button>Browse Airdrops</Button>
                  </Link>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="completed" className="space-y-4">
            {completedLoading ? (
              <div className="text-center py-8">Loading completed airdrops...</div>
            ) : completedAirdrops.length > 0 ? (
              <div className="grid gap-4">
                {completedAirdrops.map((airdrop) => (
                  <Card key={airdrop.id} className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2">
                          <CheckCircle2 className="h-4 w-4 text-green-500" />
                          <Link to={`/airdrop/${airdrop.id}`}>
                            <h3 className="font-semibold hover:text-primary cursor-pointer">
                              {airdrop.title}
                            </h3>
                          </Link>
                        </div>
                        <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                          {airdrop.description}
                        </p>
                        <div className="flex items-center space-x-4 mt-3">
                          <Badge variant="secondary">Completed</Badge>
                          {airdrop.potential_profit && (
                            <span className="text-sm text-green-600 font-medium">
                              Earned: {airdrop.potential_profit}
                            </span>
                          )}
                          <span className="text-xs text-muted-foreground">
                            Completed {airdrop.completedAt ? new Date(airdrop.completedAt).toLocaleDateString() : 'recently'}
                          </span>
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="text-center py-8">
                  <CheckCircle2 className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No completed airdrops yet</h3>
                  <p className="text-muted-foreground mb-4">
                    Complete airdrop tutorials to earn rewards and track your progress.
                  </p>
                  <Link to="/airdrops">
                    <Button>Start Earning</Button>
                  </Link>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="recommended" className="space-y-4">
            {recommendedLoading ? (
              <div className="text-center py-8">Loading recommendations...</div>
            ) : recommendedAirdrops.length > 0 ? (
              <div className="grid gap-4">
                {recommendedAirdrops.map((airdrop) => (
                  <Card key={airdrop.id} className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2">
                          <Star className="h-4 w-4 text-yellow-500" />
                          <Link to={`/airdrop/${airdrop.id}`}>
                            <h3 className="font-semibold hover:text-primary cursor-pointer">
                              {airdrop.title}
                            </h3>
                          </Link>
                        </div>
                        <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                          {airdrop.description}
                        </p>
                        <div className="flex items-center space-x-4 mt-3">
                          <Badge variant="default">Recommended</Badge>
                          {airdrop.potential_profit && (
                            <span className="text-sm text-green-600 font-medium">
                              {airdrop.potential_profit}
                            </span>
                          )}
                          <span className="text-xs text-muted-foreground flex items-center">
                            <Eye className="h-3 w-3 mr-1" />
                            {airdrop.views || 0}
                          </span>
                        </div>
                      </div>
                      <div className="flex space-x-2 ml-4">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => toggleSavedMutation.mutate(airdrop.id)}
                          disabled={toggleSavedMutation.isPending}
                        >
                          <BookmarkIcon className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="text-center py-8">
                  <Star className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No recommendations yet</h3>
                  <p className="text-muted-foreground mb-4">
                    Complete more airdrops to get personalized recommendations.
                  </p>
                  <Link to="/airdrops">
                    <Button>Explore Airdrops</Button>
                  </Link>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </SidebarLayout>
  );
}