import { useState, useEffect } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Helmet } from "react-helmet";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import Sidebar from "@/components/layout/sidebar";
import { useToast } from "@/hooks/use-toast";
import { InsertAirdrops } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle, Loader2, Megaphone } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { RichTextEditor } from "@/components/ui/rich-text-editor";

export default function PostNewsPage() {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [formData, setFormData] = useState<Partial<InsertAirdrops>>({
    title: "",
    description: "",
    tags: [],
    link: "",
    potential_profit: "",
    status: "active",
    category_id: 4, // Default to News category for announcements
    post_type: "announcement",
    is_banner: true,
  });
  
  const [errors, setErrors] = useState<Record<string, string>>({});
  
  const createNewsMutation = useMutation({
    mutationFn: async (data: { formData: Partial<InsertAirdrops> }) => {
      const res = await apiRequest("POST", "/api/airdrops", data.formData);
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/airdrops"] });
      queryClient.invalidateQueries({ queryKey: ["/api/airdrops/announcements"] });
      queryClient.invalidateQueries({ queryKey: ["/api/airdrops/banner"] });
      toast({
        title: "News posted successfully",
        description: "Your news announcement has been published.",
      });
      // Navigate back to announcements
      navigate("/announcements");
    },
    onError: (error: Error) => {
      toast({
        title: "Error posting news",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Check if user is admin
  useEffect(() => {
    if (user && !user.isAdmin) {
      toast({
        title: "Admin Privileges Required",
        description: "Only administrators can post news announcements.",
        variant: "destructive",
      });
      navigate("/");
    }
  }, [user, navigate, toast]);
  
  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.title?.trim()) {
      newErrors.title = "Title is required";
    }
    
    if (!formData.description?.trim()) {
      newErrors.description = "Content is required";
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  

  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    // Prepare the data for submission
    const submissionData = {
      ...formData,
      post_type: "announcement" as const,
    };
    
    createNewsMutation.mutate({
      formData: submissionData
    });
  };
  
  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Please log in</h2>
          <p className="text-gray-600 dark:text-gray-400">You need to be logged in to post news.</p>
        </div>
      </div>
    );
  }
  
  return (
    <>
      <Helmet>
        <title>Post News - Crypto Airdrop Platform</title>
        <meta name="description" content="Post news and announcements for the crypto community" />
      </Helmet>
      
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800">
        <Sidebar />
        
        <main className="md:ml-64 p-6 md:p-10">
          <div className="max-w-4xl mx-auto">
            <div className="mb-8">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-3 bg-orange-100 dark:bg-orange-900/30 rounded-lg">
                  <Megaphone className="h-6 w-6 text-orange-600 dark:text-orange-400" />
                </div>
                <div>
                  <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Post News</h1>
                  <p className="text-gray-600 dark:text-gray-400">Share important news and announcements with the community</p>
                </div>
              </div>
            </div>
            
            <Card className="border-2 border-orange-200 dark:border-orange-800">
              <CardHeader className="bg-gradient-to-r from-orange-50 to-amber-50 dark:from-orange-900/20 dark:to-amber-900/20">
                <CardTitle className="text-orange-800 dark:text-orange-200">News Announcement</CardTitle>
                <CardDescription>
                  Create a news announcement that will be visible to all platform users
                </CardDescription>
              </CardHeader>
              
              <form onSubmit={handleSubmit}>
                <CardContent className="p-6 space-y-6">
                  {/* Title */}
                  <div>
                    <Label htmlFor="title" className="text-base font-medium">Title *</Label>
                    <Input
                      id="title"
                      value={formData.title || ""}
                      onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                      placeholder="Enter news title..."
                      className={errors.title ? "border-red-500" : ""}
                    />
                    {errors.title && <p className="text-red-500 text-sm mt-1">{errors.title}</p>}
                  </div>
                  
                  {/* Content */}
                  <div>
                    <Label className="text-base font-medium">Content *</Label>
                    <RichTextEditor
                      value={formData.description || ""}
                      onChange={(value) => setFormData({ ...formData, description: value })}
                      placeholder="Write your news content here..."
                    />
                    {errors.description && <p className="text-red-500 text-sm mt-1">{errors.description}</p>}
                  </div>
                  
                  {/* Banner Option */}
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="is_banner"
                      checked={formData.is_banner || false}
                      onCheckedChange={(checked) => setFormData({ ...formData, is_banner: !!checked })}
                    />
                    <Label htmlFor="is_banner" className="text-sm">
                      Display as banner announcement (appears prominently at top of site)
                    </Label>
                  </div>
                </CardContent>
                
                <CardFooter className="flex justify-between">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => navigate("/announcements")}
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="submit" 
                    disabled={createNewsMutation.isPending}
                    className="bg-orange-600 hover:bg-orange-700 text-white"
                  >
                    {createNewsMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Publishing...
                      </>
                    ) : (
                      <>
                        <Megaphone className="mr-2 h-4 w-4" />
                        Publish News
                      </>
                    )}
                  </Button>
                </CardFooter>
              </form>
            </Card>
          </div>
        </main>
      </div>
    </>
  );
}