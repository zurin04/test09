import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Helmet } from "react-helmet";
import LegalHeader from "@/components/layout/legal-header";

export default function CookiePolicy() {
  return (
    <>
      <Helmet>
        <title>Cookie Policy | AirdropVerse</title>
        <meta name="description" content="Information about how AirdropVerse uses cookies and similar technologies." />
      </Helmet>
      
      <LegalHeader />
      
      <div className="container py-10 max-w-4xl mx-auto">
        <Card className="border-gray-800 shadow-lg">
          <CardHeader className="border-b border-gray-800">
            <CardTitle className="text-2xl font-bold">Cookie Policy</CardTitle>
          </CardHeader>
          
          <CardContent className="pt-6 prose prose-invert max-w-none">
            <p className="text-sm text-gray-400">Last updated: May 10, 2025</p>
            
            <h2>1. What Are Cookies</h2>
            <p>
              Cookies are small pieces of text data stored on your device when you browse websites. 
              They are widely used to make websites work more efficiently and provide information to the website owners.
            </p>

            <h2>2. How We Use Cookies</h2>
            <p>AirdropVerse uses cookies for several purposes, including:</p>
            <ul>
              <li><strong>Essential Cookies:</strong> These cookies are required for the basic functionality of our website. They enable core features such as security, account management, and network management. The website cannot function properly without these cookies.</li>
              <li><strong>Functional Cookies:</strong> These cookies allow us to remember choices you make and provide enhanced features. They may be set by us or by third-party providers whose services we have added to our pages.</li>
              <li><strong>Analytics Cookies:</strong> These cookies help us understand how visitors interact with our website by collecting and reporting information anonymously. This helps us improve our website's structure and content.</li>
              <li><strong>Marketing Cookies:</strong> These cookies track your online activity to help advertisers deliver more relevant advertising or to limit how many times you see an ad. These cookies can share that information with other organizations or advertisers.</li>
              <li><strong>Session Cookies:</strong> These cookies remember your login session and preferences while using our platform.</li>
            </ul>

            <h2>3. Types of Cookies We Use</h2>
            <h3>3.1 First-Party Cookies</h3>
            <p>
              First-party cookies are set by AirdropVerse directly when you visit our website. 
              These are used primarily for essential website functions and to remember your preferences.
            </p>

            <h3>3.2 Third-Party Cookies</h3>
            <p>
              Third-party cookies are set by our partners and service providers. These might include analytics services 
              (like Google Analytics), advertising networks, or social media platforms. 
              These partners may use cookies, web beacons, and similar technologies to collect information about your use of our website.
            </p>

            <h2>4. Cookie Duration</h2>
            <ul>
              <li><strong>Session Cookies:</strong> These cookies are temporary and are erased when you close your browser.</li>
              <li><strong>Persistent Cookies:</strong> These cookies remain on your device until they expire or you delete them. The duration varies depending on the purpose of the cookie.</li>
            </ul>

            <h2>5. Specific Cookies We Use</h2>
            <table className="w-full border-collapse border border-gray-700 my-4">
              <thead>
                <tr className="bg-gray-800">
                  <th className="border border-gray-700 p-2 text-left">Cookie Name</th>
                  <th className="border border-gray-700 p-2 text-left">Purpose</th>
                  <th className="border border-gray-700 p-2 text-left">Duration</th>
                  <th className="border border-gray-700 p-2 text-left">Type</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="border border-gray-700 p-2">session</td>
                  <td className="border border-gray-700 p-2">Manages user sessions and authentication</td>
                  <td className="border border-gray-700 p-2">Session</td>
                  <td className="border border-gray-700 p-2">Essential</td>
                </tr>
                <tr>
                  <td className="border border-gray-700 p-2">connect.sid</td>
                  <td className="border border-gray-700 p-2">Maintains user login state</td>
                  <td className="border border-gray-700 p-2">Session</td>
                  <td className="border border-gray-700 p-2">Essential</td>
                </tr>
                <tr>
                  <td className="border border-gray-700 p-2">_ga</td>
                  <td className="border border-gray-700 p-2">Google Analytics - Used to distinguish users</td>
                  <td className="border border-gray-700 p-2">2 years</td>
                  <td className="border border-gray-700 p-2">Analytics</td>
                </tr>
                <tr>
                  <td className="border border-gray-700 p-2">_gid</td>
                  <td className="border border-gray-700 p-2">Google Analytics - Used to distinguish users</td>
                  <td className="border border-gray-700 p-2">24 hours</td>
                  <td className="border border-gray-700 p-2">Analytics</td>
                </tr>
                <tr>
                  <td className="border border-gray-700 p-2">_gat</td>
                  <td className="border border-gray-700 p-2">Google Analytics - Used to throttle request rate</td>
                  <td className="border border-gray-700 p-2">1 minute</td>
                  <td className="border border-gray-700 p-2">Analytics</td>
                </tr>
                <tr>
                  <td className="border border-gray-700 p-2">darkMode</td>
                  <td className="border border-gray-700 p-2">Remembers user's theme preference</td>
                  <td className="border border-gray-700 p-2">1 year</td>
                  <td className="border border-gray-700 p-2">Functional</td>
                </tr>
              </tbody>
            </table>

            <h2>6. Managing Cookies</h2>
            <p>
              Most web browsers allow you to manage your cookie preferences. You can:
            </p>
            <ul>
              <li>Delete cookies from your device</li>
              <li>Block cookies by activating the setting on your browser that allows you to refuse all or some cookies</li>
              <li>Set your browser to notify you when you receive a cookie</li>
            </ul>
            <p>
              Please note that if you choose to disable cookies, some parts of our website may not function properly. 
              Different browsers provide different methods to block and delete cookies. 
              Please visit your browser's help section for instructions.
            </p>

            <h2>7. Changes to Our Cookie Policy</h2>
            <p>
              We may update our Cookie Policy from time to time. We will notify you of any changes by posting the new Cookie Policy on this page.
            </p>

            <h2>8. Contact Us</h2>
            <p>
              If you have any questions about our Cookie Policy, please contact us at:<br />
              Email: privacy@airdropverse.com
            </p>
          </CardContent>
        </Card>
      </div>
    </>
  );
}