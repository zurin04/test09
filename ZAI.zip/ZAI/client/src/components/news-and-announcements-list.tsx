import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { formatDistanceToNow } from "date-fns";
import type { Airdrops } from "@shared/schema";

export default function NewsAndAnnouncementsList() {
  const { data: announcements, isLoading, error } = useQuery<Airdrops[]>({
    queryKey: ['/api/airdrops/announcements'],
    queryFn: async () => {
      const res = await fetch('/api/airdrops/announcements');
      if (!res.ok) {
        throw new Error('Failed to fetch announcements');
      }
      const data = await res.json();
      return Array.isArray(data) ? data : [];
    },
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <Card key={i} className="bg-blue-800/20 border-blue-700/30 animate-pulse">
            <CardContent className="p-6">
              <div className="space-y-3">
                <div className="h-4 bg-blue-700/50 rounded w-3/4"></div>
                <div className="h-3 bg-blue-700/30 rounded w-1/2"></div>
                <div className="h-16 bg-blue-700/30 rounded"></div>
                <div className="flex space-x-2">
                  <div className="h-5 bg-blue-700/30 rounded w-16"></div>
                  <div className="h-5 bg-blue-700/30 rounded w-20"></div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (error || !announcements) {
    return (
      <div className="text-center py-12">
        <div className="bg-blue-800/20 border border-blue-700/30 rounded-lg p-8 max-w-md mx-auto">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-blue-400 mx-auto mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z" />
          </svg>
          <h3 className="text-lg font-semibold text-white mb-2">No Announcements Available</h3>
          <p className="text-blue-200">
            Check back later for the latest platform updates and news.
          </p>
        </div>
      </div>
    );
  }

  if (announcements.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="bg-blue-800/20 border border-blue-700/30 rounded-lg p-8 max-w-md mx-auto">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-blue-400 mx-auto mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z" />
          </svg>
          <h3 className="text-lg font-semibold text-white mb-2">Stay Tuned!</h3>
          <p className="text-blue-200">
            New announcements and platform updates will appear here.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {announcements.slice(0, 6).map((announcement) => (
        <Link key={announcement.id} href={`/airdrops/${announcement.id}`}>
          <Card className="bg-blue-800/20 border-blue-700/30 hover:bg-blue-800/30 hover:border-blue-600/40 transition-all duration-300 cursor-pointer group h-full">
            <CardContent className="p-6 h-full flex flex-col">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center space-x-2">
                  <Badge 
                    variant="secondary" 
                    className={`text-xs ${
                      announcement.post_type === 'announcement' 
                        ? 'bg-blue-600/20 text-blue-300 border-blue-500/30' 
                        : 'bg-green-600/20 text-green-300 border-green-500/30'
                    }`}
                  >
                    {announcement.post_type === 'announcement' ? '📢 News' : '🔔 Update'}
                  </Badge>
                </div>
                <span className="text-xs text-blue-300">
                  {formatDistanceToNow(new Date(announcement.created_at))} ago
                </span>
              </div>
              
              <h3 className="text-lg font-semibold text-white mb-3 group-hover:text-blue-200 transition-colors line-clamp-2">
                {announcement.title}
              </h3>
              
              <div 
                className="text-blue-100 text-sm mb-4 line-clamp-3 flex-grow"
                dangerouslySetInnerHTML={{ 
                  __html: announcement.description.replace(/<[^>]*>/g, '').substring(0, 120) + '...' 
                }}
              />
              
              <div className="flex items-center justify-between mt-auto pt-3 border-t border-blue-700/20">
                <div className="flex items-center space-x-3 text-xs text-blue-300">
                  <div className="flex items-center space-x-1">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                    </svg>
                    <span>{announcement.views}</span>
                  </div>
                  {announcement.posted_by && (
                    <div className="flex items-center space-x-1">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                      </svg>
                      <span>{announcement.posted_by}</span>
                    </div>
                  )}
                </div>
                
                <div className="flex items-center text-blue-400 group-hover:text-blue-300 transition-colors">
                  <span className="text-xs mr-1">Read more</span>
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </div>
              </div>
            </CardContent>
          </Card>
        </Link>
      ))}
    </div>
  );
}