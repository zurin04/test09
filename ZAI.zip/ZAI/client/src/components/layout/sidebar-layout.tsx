import { ReactNode } from "react";
import { Helmet } from "react-helmet";
import { useQuery } from "@tanstack/react-query";
import { SiteSettings } from "@shared/schema";
import Sidebar from "./sidebar";

interface SidebarLayoutProps {
  children: ReactNode;
  title?: string;
}

export default function SidebarLayout({ children, title }: SidebarLayoutProps) {
  // Fetch site settings for dynamic branding
  const { data: siteSettings } = useQuery<SiteSettings>({
    queryKey: ["/api/site-settings"],
  });
  
  const siteName = siteSettings?.site_name || "AirdropHub";
  const pageTitle = title ? `${title} - ${siteName}` : siteName;
  
  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-background">
      <Helmet>
        <title>{pageTitle}</title>
      </Helmet>
      
      <Sidebar />
      
      <main className="flex-1 overflow-x-hidden">
        {children}
      </main>
    </div>
  );
}