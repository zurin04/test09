import { useState, useEffect, useRef } from "react";
import { useChat } from "@/hooks/use-chat";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";

export default function ChatRoom() {
  const { user } = useAuth();
  const { messages, onlineUsers, sendMessage, isConnecting, getUserProfileImage } = useChat();
  const [newMessage, setNewMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [guestName] = useState(() => `Guest_${Math.floor(Math.random() * 10000)}`);
  
  // Auto-scroll to bottom on new messages
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);
  
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (newMessage.trim()) {
      sendMessage({
        user: user ? user.username : guestName,
        message: newMessage,
        isAdmin: user?.isAdmin || false,
        isCreator: user?.isCreator || false,
      });
      setNewMessage("");
    }
  };
  
  // Format timestamp
  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };
  
  // Function to get profile image for a user if available
  const getLocalUserProfileImage = (username: string) => {
    // If the message is from the current logged-in user
    if (user && user.username === username && user.profile_image) {
      return user.profile_image;
    }
    
    // For all other users, use the cached image from our hook
    return getUserProfileImage(username);
  };

  // Group messages by date
  const getMessageDate = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleDateString();
  };

  return (
    <Card className="shadow-lg border border-gray-800">
      <CardHeader className="border-b border-gray-700 flex flex-row items-center justify-between">
        <div className="flex items-center">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m0 0L11 14h4a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2v4l.586-.586z" />
          </svg>
          <CardTitle>General Chat</CardTitle>
        </div>
        <div className="flex items-center text-sm text-gray-400">
          <div className="flex items-center mr-4">
            <div className="w-2 h-2 bg-green-500 rounded-full mr-1"></div>
            <span>{onlineUsers} online</span>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="p-0">
        <div className="chat-messages p-4 space-y-4">
          {isConnecting ? (
            <div className="flex justify-center py-4">
              <div className="animate-spin h-6 w-6 border-2 border-primary border-t-transparent rounded-full"></div>
            </div>
          ) : messages.length === 0 ? (
            <div className="flex justify-center py-8">
              <div className="text-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto text-muted-foreground mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                </svg>
                <p className="text-muted-foreground">No messages yet. Be the first to say hello!</p>
              </div>
            </div>
          ) : (
            <>
              {/* Group messages by date */}
              {messages.reduce((grouped, message, index, array) => {
                const currentDate = getMessageDate(message.timestamp);
                const prevDate = index > 0 ? getMessageDate(array[index - 1].timestamp) : null;
                
                if (index === 0 || currentDate !== prevDate) {
                  grouped.push(
                    <div key={`date-${currentDate}`} className="flex justify-center">
                      <span className="text-xs bg-background px-3 py-1 rounded-full text-gray-400">
                        {currentDate === getMessageDate(new Date().toISOString()) 
                          ? "Today" 
                          : currentDate}
                      </span>
                    </div>
                  );
                }
                
                grouped.push(
                  <div key={`msg-${index}`} className="flex items-start">
                    <Avatar className={`mr-3 ${
                      message.isAdmin 
                        ? "bg-red-600 ring-1 ring-red-400" 
                        : message.isCreator 
                          ? "bg-amber-700 ring-2 ring-amber-400 ring-offset-1 ring-offset-amber-900" 
                          : message.user === (user?.username || guestName) 
                            ? "bg-blue-600" 
                            : "bg-purple-600"
                    }`}>
                      {getLocalUserProfileImage(message.user) && (
                        <img src={getLocalUserProfileImage(message.user) || ''} alt={message.user} className="h-full w-full object-cover" />
                      )}
                      {message.isAdmin && !getLocalUserProfileImage(message.user) && (
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                        </svg>
                      )}
                      {!message.isAdmin && !getLocalUserProfileImage(message.user) && (
                        <AvatarFallback className={message.isCreator ? "text-amber-200" : ""}>
                          {message.user.substring(0, 2).toUpperCase()}
                        </AvatarFallback>
                      )}
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center mb-1">
                        <span className={`font-medium mr-2 ${message.isCreator ? "text-amber-400" : "text-white"}`}>
                          {message.user}
                        </span>
                        {message.isAdmin && (
                          <Badge variant="destructive" className="mr-2">ADMIN</Badge>
                        )}
                        {message.isCreator && !message.isAdmin && (
                          <Badge className="mr-2 bg-amber-600 hover:bg-amber-700">CREATOR</Badge>
                        )}
                        <span className="text-xs text-gray-500">{formatTimestamp(message.timestamp)}</span>
                      </div>
                      <p className="text-gray-300 text-sm">{message.message}</p>
                    </div>
                  </div>
                );
                
                return grouped;
              }, [] as JSX.Element[])}
              
              <div ref={messagesEndRef} />
            </>
          )}
        </div>
      </CardContent>
      
      <CardFooter className="p-4 border-t border-gray-700">
        <form onSubmit={handleSendMessage} className="w-full">
          <div className="flex items-center">
            <Input 
              type="text" 
              placeholder="Type your message..." 
              className="flex-1 bg-background border border-border"
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              disabled={isConnecting}
            />
            <Button 
              type="submit" 
              className="ml-2" 
              disabled={!newMessage.trim() || isConnecting}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
              </svg>
              <span className="sr-only">Send</span>
            </Button>
          </div>
          <div className="flex justify-between mt-2">
            <div className="text-xs text-gray-500">
              {!user ? (
                <>
                  <span>Joining as {guestName}</span> · <Link to="/auth" className="text-primary hover:text-blue-400">Sign in</Link>
                </>
              ) : (
                <span>Chatting as {user.username}</span>
              )}
            </div>
            <div className="flex items-center space-x-2">
              <button 
                type="button" 
                className="text-gray-500 hover:text-gray-300 text-sm"
                onClick={() => setNewMessage(prev => prev + "😊")}
                disabled={isConnecting}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.828 14.828a4 4 0 01-5.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <span className="sr-only">Add emoji</span>
              </button>
            </div>
          </div>
        </form>
      </CardFooter>
    </Card>
  );
}
