# Crypto Airdrop Platform

## Overview

A comprehensive cryptocurrency airdrop discovery platform built with modern web technologies. The platform enables users to explore, learn about, and participate in cryptocurrency airdrops through step-by-step tutorials, real-time community chat, and advanced user management features.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety
- **Build Tool**: Vite for fast development and optimized builds
- **Styling**: Tailwind CSS with shadcn/ui component library for consistent design
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Animation**: Framer Motion for smooth UI transitions
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Runtime**: Node.js 20 with TypeScript
- **Framework**: Express.js for RESTful API endpoints
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Authentication**: Passport.js with support for traditional and Web3 wallet authentication (SIWE)
- **Session Management**: Express-session with PostgreSQL store
- **Real-time Communication**: WebSocket server for live chat functionality
- **File Upload**: Multer for handling image uploads

## Key Components

### Authentication System
- **Traditional Auth**: Username/password authentication with bcrypt hashing
- **Web3 Integration**: Ethereum wallet connection using Sign-In with Ethereum (SIWE)
- **Role-based Access**: Admin, Creator, and User roles with different permissions
- **Session Security**: Secure session management with configurable expiration

### Database Schema
- **Users**: Core user data with Web3 wallet support and role management
- **Airdrops**: Comprehensive airdrop information with categorization and tracking
- **Categories**: Organizational structure for airdrop classification
- **Creator Applications**: System for users to apply for creator status
- **Site Settings**: Dynamic configuration management
- **Newsletter**: Email subscription management
- **Comments**: User comments on airdrops with user relationships and timestamps
- **Likes**: User likes/reactions on airdrops with real-time counting

### Real-time Features
- **Global Chat**: WebSocket-powered community chat with admin moderation
- **Live Updates**: Real-time cryptocurrency price tracking
- **Connection Management**: Heartbeat mechanism for connection reliability
- **Creator Timeline**: Interactive timeline showing creator's airdrops with comment and like functionality
- **User Interactions**: Real-time comments and likes system with permission-based moderation

## Data Flow

1. **User Registration/Login**: 
   - Traditional: Username/password → bcrypt hashing → session creation
   - Web3: Wallet connection → SIWE message generation → signature verification → session creation

2. **Airdrop Management**:
   - Content creation through rich editor → validation → database storage
   - Category-based organization → filtered retrieval → client-side display
   - View tracking and analytics collection

3. **Real-time Communication**:
   - WebSocket connection establishment → message broadcasting → client synchronization
   - Admin moderation capabilities → message filtering → user management

4. **File Management**:
   - Image upload → server-side processing → secure storage → URL generation
   - Profile image management → avatar system integration

## External Dependencies

### Cryptocurrency Data
- **CoinGecko API**: Live price feeds and market data
- **Caching Strategy**: 1-minute TTL to reduce API calls and improve performance

### Third-party Services
- **Replit Integration**: Development environment with cartographer plugin
- **PostgreSQL**: Primary database with connection pooling
- **Web3 Libraries**: SIWE for Ethereum wallet authentication

### Security Dependencies
- **bcrypt**: Password hashing with salt generation
- **express-session**: Secure session management
- **CORS**: Cross-origin resource sharing configuration
- **Input Validation**: Zod schemas for request validation

## Deployment Strategy

### Development Environment
- **Replit Configuration**: Automated setup with PostgreSQL module
- **Hot Reload**: Vite development server with HMR
- **Environment Variables**: Separate development and production configurations

### Production Deployment (Single-Script VPS Setup)
- **Deployment Script**: `deploy-vps.sh` - One-command VPS deployment
- **Management Script**: `manage.sh` - Comprehensive management tools
- **Documentation**: `README-DEPLOY.md` - Simple deployment guide

### VPS Infrastructure
- **Operating System**: Ubuntu 20.04+ or Debian 11+ support
- **Process Management**: PM2 with automatic restarts and logging
- **Web Server**: Nginx reverse proxy with security headers
- **Database**: PostgreSQL with secure user and connection pooling
- **Security**: UFW firewall, secure file permissions, security headers
- **Monitoring**: Health checks, resource monitoring, log analysis
- **Backup System**: Automated database backups with 7-day retention
- **SSL Support**: Certbot integration for SSL certificate management

### Automated Features
- **One-Command Deploy**: Single script handles entire production setup
- **Dependency Management**: Automatic installation of Node.js 20, PostgreSQL, Nginx, PM2
- **Database Setup**: Secure database creation with encoded password handling
- **Build Optimization**: Extended timeout and memory optimization for builds
- **Service Configuration**: PM2 ecosystem, Nginx sites, firewall rules
- **Management Tools**: Start/stop, logs, backups, updates, SSL setup, health checks

## Changelog

- June 14, 2025: Initial project setup and architecture
- June 21, 2025: Streamlined Docker deployment system (deprecated)
- June 26, 2025: Complete VPS deployment system overhaul (legacy - removed)
- June 27, 2025: **Final streamlined VPS deployment system:**
  - **Complete cleanup**: Removed all old deployment scripts and unnecessary files
  - **New `deploy-vps.sh`**: Single-command VPS deployment based on HOPEMPC reference
  - **Enhanced `manage.sh`**: Comprehensive management with backup, update, SSL, health check
  - **Simplified `README-DEPLOY.md`**: Clear deployment guide and troubleshooting
  - **Database setup**: Secure PostgreSQL with user creation and password encoding
  - **Build optimization**: Extended timeout, memory optimization, fallback strategies
  - **Security hardening**: UFW firewall, Nginx security headers, secure credentials
  - **Production ready**: PM2 process management, automated backups, SSL support
  - **Management features**: Health monitoring, safe updates, backup/restore system
- June 28, 2025: **Enhanced social navigation and admin styling features:**
  - **Clickable creator names**: Added clickable creator names in airdrop cards and details pages that redirect to creator timelines
  - **Creator navigation**: Added "My Timeline" link in sidebar navigation for creators and admins
  - **Password management**: Moved password change functionality from profile tabs to dedicated navigation page
  - **Improved UX**: Streamlined profile page by removing security tab and creating standalone change password page
  - **Route updates**: Fixed creator timeline routing to use `/creator-timeline/:username` format
  - **Enhanced creator timelines**: Fixed routing issues and added comprehensive public information display
  - **Social media integration**: Added full support for Twitter, Discord, and Telegram links in creator profiles
  - **Rich text editor**: Implemented advanced post editor with headings (H1-H3), bold, italic, links, and lists
  - **Timeline display**: Fixed HTML rendering in creator timeline posts for proper content formatting
  - **Creator information**: Enhanced "No Posts Yet" section with detailed creator verification and bio display
  - **Admin auto-creator status**: Admin users are now automatically treated as creators without needing to apply
  - **Lightning border effects**: Added attractive animated lightning borders for admin users across the platform
  - **Unique timeline designs**: Created distinctive visual styles for admin vs creator timelines with gradient colors and special effects
  - **Enhanced admin presence**: Admin users now have lightning-themed avatars, badges, and special styling in sidebar, chat, and profile pages
  - **Admin profile enhancements**: Updated profile page to show admin-specific creator status with lightning styling and automatic privileges
  - **Refined sidebar design**: Removed overwhelming lightning border effects from sidebar authentication section while maintaining admin badges
  - **Enhanced timeline borders**: Added distinctive border effects - lightning borders for admin timelines and golden borders with shadows for creator timelines
- June 30, 2025: **Comprehensive platform improvements and VPS deployment verification:**
  - **Complete 14-improvement implementation**: Successfully implemented all requested platform enhancements including advanced search, user dashboard, notifications, analytics, gamification, mobile experience, dark mode, PWA features, email system, and multi-language support
  - **VPS deployment system testing**: Thoroughly tested and verified production-ready deployment system with one-command VPS setup
  - **Production deployment verification**: Confirmed complete deployment pipeline including database setup, build optimization, security hardening, and management tools
  - **Multi-language support**: Added comprehensive internationalization with 8 languages (English, Spanish, French, German, Chinese, Japanese, Korean, Russian)
  - **Advanced user engagement**: Implemented achievement system, leaderboards, progress tracking, and gamification elements
  - **Analytics integration**: Added Google Analytics foundation with user engagement tracking and page view monitoring
  - **Email notification system**: Integrated SendGrid email service for user notifications and milestone communications
  - **PWA capabilities**: Added progressive web app features with offline support foundation and mobile app-like experience
  - **Enhanced mobile experience**: Implemented responsive navigation, touch-friendly interfaces, and mobile-first design principles
  - **Complete dark mode system**: Added theme toggle functionality with comprehensive light/dark mode support across all components
  - **Real-time notification system**: Implemented WebSocket-based notifications with user preference management and status tracking
  - **Advanced search and filtering**: Created comprehensive search system with tag filtering, profit level sorting, and real-time results
  - **User dashboard enhancement**: Built complete user statistics tracking with saved/completed airdrops management and progress visualization
- July 03, 2025: **Image upload fixes and news ticker removal:**
  - **Fixed image upload system**: Corrected image passing in create-post.tsx mutation to properly send images to server
  - **Enhanced image display**: Updated airdrop cards and details pages to show images for all post types, not just announcements
  - **Database setup**: Created missing "News" category (ID 4) for announcement posts to resolve foreign key constraints
  - **Verified image functionality**: Confirmed image uploads work correctly with proper file storage and URL generation
  - **Removed news ticker banner**: Completely removed NewsTicker component from application layout per user request
  - **Cleaned up navigation**: Simplified top navigation by removing the rotating news banner for cleaner interface
  - **Removed duplicate post banner navigation**: Eliminated "Post Banner" sidebar link since it duplicated "Post News" functionality
  - **File cleanup**: Deleted unused news-ticker.tsx and post-banner.tsx component files from project structure
  - **Streamlined admin interface**: Consolidated news posting to single "Post News" option for better UX
  - **Simplified news posting form**: Removed tags, links, and image upload from news posting - kept only title and content fields
  - **Enhanced admin workflow**: News posting now focuses on essential content with banner display option for top placement
- July 03, 2025: **VPS deployment updates and production optimization:**
  - **Updated deployment script**: Enhanced deploy-vps.sh with complete environment variable support
  - **Added PostgreSQL environment variables**: Included PGHOST, PGPORT, PGUSER, PGPASSWORD, PGDATABASE for better compatibility
  - **PM2 configuration improvements**: Updated ecosystem.config.cjs with all necessary environment variables
  - **Production environment template**: Updated .env.production with optional email and analytics configuration
  - **Enhanced documentation**: Added domain configuration, SSL setup, and news system feature descriptions to README-DEPLOY.md
  - **Feature documentation**: Documented latest news system capabilities and role-based posting restrictions
  - **Deployment verification**: Confirmed production deployment includes all latest platform enhancements
- July 02, 2025: **News system fixes and admin-only restrictions:**
  - **Fixed post news navigation**: Created dedicated `/post-news` page for admin users with proper routing
  - **Moved Post News to top**: Positioned prominently at top of sidebar navigation for immediate access
  - **Enhanced news ticker**: Added attractive news ticker displaying banner announcements with rotation and progress bar
  - **Admin-only restrictions**: Ensured only administrators can post news announcements and access news posting features
  - **Server-side validation**: Added backend validation to enforce admin permissions for announcement creation
  - **Frontend restrictions**: Updated navigation and UI components to show news posting options only to admin users
  - **News display system**: Implemented news ticker at top of site with auto-rotation, close button, and navigation controls
  - **Complete admin-only enforcement**: News posting and announcement features are now strictly limited to admin users only
- June 30, 2025: **Chat system fix, content cleanup, and comprehensive dashboard/sidebar modernization:**
  - **Chat online user tracking fix**: Fixed WebSocket chat system to track unique users instead of browser tabs/connections
  - **User session management**: Users with multiple tabs now correctly show as single online user in chat
  - **WebSocket improvements**: Enhanced connection handling with proper user identification and cleanup on disconnect
  - **Content type simplification**: Removed "upcoming" post type from system, keeping only "announcement" and "airdrop_steps"
  - **UI consistency**: Updated all forms, components, and validation to reflect simplified content structure
  - **Backend validation**: Updated server-side validation and API endpoints to match new post type restrictions
  - **Database optimization**: Cleaned up post type references and schema validation throughout the application
  - **Dashboard overhaul**: Completely redesigned admin dashboard with modern overview cards, statistics, and quick action sections
  - **Sidebar modernization**: Enhanced sidebar with gradient backgrounds, smooth animations, collapsible functionality, and role-based visual styling
  - **Visual hierarchy improvements**: Added better spacing, icons, color-coded sections, and interactive hover states throughout navigation
  - **Admin/Creator styling**: Implemented distinctive visual treatments for admin and creator sections with lightning and gradient effects
  - **Responsive design**: Improved mobile experience with proper collapsible states and touch-friendly interactions
  - **Statistics integration**: Added real-time dashboard metrics showing airdrops, users, views, and newsletter subscribers
  - **Quick actions**: Implemented card-based quick action system for common admin tasks with hover animations
  - **Navigation separation**: Separated posting navigation into distinct "Post Airdrop Tutorial" and "Post News" buttons across all interface points
  - **Role-based content creation**: Admins can create both announcements and airdrop tutorials, creators limited to airdrop tutorials only
  - **URL parameter handling**: Added support for pre-selecting post type via URL parameters (?type=announcement)
  - **Dynamic page titles**: Page titles and descriptions now update based on content type being created
  - **Color-coded navigation**: Blue styling for airdrop tutorials, orange styling for news/announcements to improve visual distinction
  - **Comprehensive platform enhancements**: Implemented all 14 major improvement categories including advanced search, user dashboard, notifications, analytics, gamification, mobile experience, dark mode, PWA features, email system, and multi-language support foundation
- June 29, 2025: **Navigation cleanup, editor improvements, and dynamic favicon system:**
  - **Top navigation cleanup**: Removed "Post New Airdrop" button from main desktop navigation to reduce clutter
  - **VPS deployment verification**: Confirmed complete VPS deployment system is functional and production-ready
  - **Database setup**: Verified database connection, schema creation, and seeding processes work correctly
  - **Rich text editor fixes**: Fixed heading functionality that was deleting text instead of formatting it properly
  - **Post type display**: Fixed announcement posts showing incorrect labels ("Tutorial Steps" → "Announcement Content")
  - **Dynamic content labels**: Updated airdrop details page to show appropriate titles and actions based on post type
  - **Creator link styling**: Added proper padding (pl-[6px] pr-[6px]) to clickable creator names in airdrop cards
  - **Rich text editor visibility**: Fixed text visibility issues with proper foreground colors and contrast
  - **Code block support**: Added comprehensive code block functionality with copy buttons in rich text editor
  - **Copy functionality**: Implemented copy-to-clipboard features for code blocks in all displayed content
  - **Dynamic favicon system**: Created automatic tab logo updates based on admin-uploaded logos from site settings
  - **Post ownership authorization**: Confirmed proper implementation ensuring only post creators can edit/delete their own posts
  - **News and announcements system**: Added dedicated API endpoint for announcements, created announcements page with filtering
  - **Permission restrictions**: Implemented role-based post type restrictions - only admins can create announcements and upcoming posts, creators limited to airdrop steps
  - **Server-side validation**: Added backend validation to enforce post type permissions for both create and update operations
  - **Frontend restrictions**: Updated both create and edit airdrop forms to conditionally show post types based on user role

## User Preferences

Preferred communication style: Simple, everyday language.