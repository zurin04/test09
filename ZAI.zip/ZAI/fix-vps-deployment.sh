#!/bin/bash

# Quick fix script for VPS deployment - Run this on your server
# This fixes the foreign key constraint error in PM2 logs

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

print_status() { echo -e "${GREEN}[✓]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[!]${NC} $1"; }
print_error() { echo -e "${RED}[✗]${NC} $1"; }

echo "========================================"
echo "Crypto Airdrop Platform - Database Fix"
echo "========================================"

# Change to application directory
cd /var/www/crypto-airdrop || { print_error "Application directory not found"; exit 1; }

# Load environment variables
if [ -f .env ]; then
    source .env
    print_status "Environment variables loaded"
else
    print_error ".env file not found"
    exit 1
fi

# Fix database categories
echo -e "\n1. Fixing database categories..."
PGPASSWORD="$PGPASSWORD" psql -h "$PGHOST" -U "$PGUSER" -d "$PGDATABASE" << 'EOF'
-- Insert missing categories if they don't exist
INSERT INTO categories (id, name, description, created_at) 
SELECT 1, 'DeFi', 'Decentralized Finance protocols and platforms', NOW()
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE id = 1);

INSERT INTO categories (id, name, description, created_at) 
SELECT 2, 'NFT', 'Non-Fungible Token projects and marketplaces', NOW()
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE id = 2);

INSERT INTO categories (id, name, description, created_at) 
SELECT 3, 'Gaming', 'Blockchain gaming and GameFi projects', NOW()
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE id = 3);

INSERT INTO categories (id, name, description, created_at) 
SELECT 4, 'News', 'Latest news and announcements', NOW()
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE id = 4);

INSERT INTO categories (id, name, description, created_at) 
SELECT 5, 'Layer 1', 'Layer 1 blockchain platforms and protocols', NOW()
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE id = 5);

INSERT INTO categories (id, name, description, created_at) 
SELECT 6, 'Layer 2', 'Layer 2 scaling solutions and side chains', NOW()
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE id = 6);

-- Update the sequence
SELECT setval('categories_id_seq', (SELECT MAX(id) FROM categories) + 1);

\echo "Categories fixed successfully"
EOF

if [ $? -eq 0 ]; then
    print_status "Database categories fixed"
else
    print_error "Failed to fix database categories"
    exit 1
fi

# Restart PM2 application
echo -e "\n2. Restarting PM2 application..."
pm2 restart crypto-airdrop

if [ $? -eq 0 ]; then
    print_status "PM2 application restarted"
else
    print_error "Failed to restart PM2 application"
fi

# Check application status
echo -e "\n3. Checking application status..."
sleep 3
if pm2 list | grep -q "crypto-airdrop.*online"; then
    print_status "Application is running successfully"
else
    print_warning "Application may still have issues - check logs with: pm2 logs crypto-airdrop"
fi

# Test HTTP response
echo -e "\n4. Testing HTTP response..."
HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:5000 2>/dev/null)
if [ "$HTTP_CODE" = "200" ]; then
    print_status "Application responding on port 5000"
else
    print_warning "Application not responding correctly (HTTP: $HTTP_CODE)"
fi

echo -e "\n========================================"
echo "Fix completed! Your application should now work correctly."
echo "- Check status: pm2 list"
echo "- View logs: pm2 logs crypto-airdrop"
echo "- Access via: http://your-domain-or-ip"
echo "========================================"