#!/bin/bash

# Crypto Airdrop Platform - Deployment Verification Script
# Verifies all features are working correctly after VPS deployment

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

print_status() { echo -e "${GREEN}[✓]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[!]${NC} $1"; }
print_error() { echo -e "${RED}[✗]${NC} $1"; }

echo "=================================="
echo "Deployment Verification Script"
echo "=================================="

# Check if running in the correct directory
if [ ! -f "package.json" ]; then
    print_error "Please run this script from the application directory (/var/www/crypto-airdrop)"
    exit 1
fi

# Test 1: Check PM2 application status
echo -e "\n1. Checking PM2 Application Status..."
if pm2 list | grep -q "crypto-airdrop.*online"; then
    print_status "PM2 application is running"
else
    print_error "PM2 application is not running"
    echo "Try: pm2 restart crypto-airdrop"
fi

# Test 2: Check database connection
echo -e "\n2. Testing Database Connection..."
if [ -f .env ]; then
    source .env
    if PGPASSWORD="$PGPASSWORD" psql -h "$PGHOST" -U "$PGUSER" -d "$PGDATABASE" -c "SELECT 1;" >/dev/null 2>&1; then
        print_status "Database connection successful"
    else
        print_error "Database connection failed"
        echo "Check DATABASE_URL and PostgreSQL service"
    fi
else
    print_warning ".env file not found"
fi

# Test 3: Check HTTP response
echo -e "\n3. Testing HTTP Response..."
if curl -s -o /dev/null -w "%{http_code}" http://localhost:5000 | grep -q "200"; then
    print_status "Application responding on port 5000"
else
    print_error "Application not responding on port 5000"
    echo "Check PM2 logs: pm2 logs crypto-airdrop"
fi

# Test 4: Check Nginx configuration
echo -e "\n4. Checking Nginx Configuration..."
if sudo nginx -t >/dev/null 2>&1; then
    print_status "Nginx configuration is valid"
else
    print_error "Nginx configuration has errors"
    echo "Run: sudo nginx -t"
fi

# Test 5: Check if Nginx is serving the app
echo -e "\n5. Testing Nginx Proxy..."
if curl -s -o /dev/null -w "%{http_code}" http://localhost | grep -q "200"; then
    print_status "Nginx proxy is working"
else
    print_error "Nginx proxy not working"
    echo "Check: sudo systemctl status nginx"
fi

# Test 6: Check database schema
echo -e "\n6. Verifying Database Schema..."
if [ -f .env ]; then
    source .env
    TABLES=$(PGPASSWORD="$PGPASSWORD" psql -h "$PGHOST" -U "$PGUSER" -d "$PGDATABASE" -t -c "SELECT count(*) FROM information_schema.tables WHERE table_schema = 'public';" 2>/dev/null | xargs)
    if [ "$TABLES" -gt 0 ]; then
        print_status "Database schema exists ($TABLES tables found)"
    else
        print_error "Database schema not found"
        echo "Run: npm run db:push && npm run db:seed"
    fi
fi

# Test 7: Check critical API endpoints
echo -e "\n7. Testing API Endpoints..."
for endpoint in "/api/categories" "/api/airdrops" "/api/site-settings"; do
    if curl -s "http://localhost:5000$endpoint" | grep -q "\["; then
        print_status "API endpoint $endpoint working"
    else
        print_warning "API endpoint $endpoint may have issues"
    fi
done

# Test 8: Check file permissions
echo -e "\n8. Checking File Permissions..."
if [ -w "public/uploads/images" ]; then
    print_status "Upload directory is writable"
else
    print_warning "Upload directory may not be writable"
    echo "Fix with: chmod 755 public/uploads/images"
fi

# Test 9: Check for SSL certificate (if domain configured)
echo -e "\n9. Checking SSL Configuration..."
if [ -d "/etc/letsencrypt/live" ] && [ "$(ls -A /etc/letsencrypt/live)" ]; then
    print_status "SSL certificates found"
else
    print_warning "No SSL certificates found (OK for IP-only setup)"
fi

# Test 10: Check news system functionality
echo -e "\n10. Testing News System..."
if curl -s "http://localhost:5000/api/airdrops/announcements" | grep -q "\["; then
    print_status "News/announcements API working"
else
    print_warning "News system may have issues"
fi

if curl -s "http://localhost:5000/api/airdrops/banner" | grep -q "\["; then
    print_status "Banner announcements API working"
else
    print_warning "Banner system may have issues"
fi

# Summary
echo -e "\n=================================="
echo "Verification Complete"
echo "=================================="

# Check overall status
if pm2 list | grep -q "crypto-airdrop.*online" && \
   curl -s -o /dev/null -w "%{http_code}" http://localhost:5000 | grep -q "200"; then
    print_status "Deployment appears to be working correctly!"
    echo -e "\nNext steps:"
    echo "1. Change default admin password (admin/admin123)"
    echo "2. Configure domain and SSL if needed"
    echo "3. Test all features in the web interface"
    echo "4. Monitor logs with: pm2 logs crypto-airdrop"
else
    print_error "Deployment has issues that need attention"
    echo -e "\nTroubleshooting:"
    echo "1. Check logs: pm2 logs crypto-airdrop"
    echo "2. Restart application: pm2 restart crypto-airdrop"
    echo "3. Check system resources: free -h && df -h"
fi

echo -e "\nFor management commands, use: ./manage.sh"