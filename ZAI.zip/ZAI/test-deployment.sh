#!/bin/bash

# Test Deployment Script - Validates VPS deployment readiness
# Tests all critical components before and after deployment

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_header() { echo -e "${BLUE}$1${NC}"; }
print_status() { echo -e "${GREEN}[✓]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[!]${NC} $1"; }
print_error() { echo -e "${RED}[✗]${NC} $1"; }

FAILED_TESTS=0
PASSED_TESTS=0

test_result() {
    if [ $1 -eq 0 ]; then
        print_status "$2"
        ((PASSED_TESTS++))
    else
        print_error "$2"
        ((FAILED_TESTS++))
    fi
}

echo "================================================"
echo "Crypto Airdrop Platform - Deployment Test Suite"
echo "================================================"

# Test 1: Check required files
print_header "\n1. Checking Required Files..."
test -f "deploy-vps.sh" && print_status "deploy-vps.sh exists" || print_error "deploy-vps.sh missing"
test -f "package.json" && print_status "package.json exists" || print_error "package.json missing"
test -f "drizzle.config.ts" && print_status "drizzle.config.ts exists" || print_error "drizzle.config.ts missing"
test -f "shared/schema.ts" && print_status "shared/schema.ts exists" || print_error "shared/schema.ts missing"
test -f "server/index.ts" && print_status "server/index.ts exists" || print_error "server/index.ts missing"

# Test 2: Validate package.json scripts
print_header "\n2. Validating Package Scripts..."
if grep -q '"build".*"vite build"' package.json; then
    print_status "Build script configured"
else
    print_error "Build script missing or incorrect"
fi

if grep -q '"start".*"node dist/index.js"' package.json; then
    print_status "Start script configured"
else
    print_error "Start script missing or incorrect"
fi

if grep -q '"db:push".*"drizzle-kit push"' package.json; then
    print_status "Database push script configured"
else
    print_error "Database push script missing or incorrect"
fi

# Test 3: Check schema structure
print_header "\n3. Validating Database Schema..."
if grep -q "export const users.*pgTable" shared/schema.ts; then
    print_status "Users table defined"
else
    print_error "Users table missing from schema"
fi

if grep -q "export const airdrops.*pgTable" shared/schema.ts; then
    print_status "Airdrops table defined"
else
    print_error "Airdrops table missing from schema"
fi

if grep -q "export const categories.*pgTable" shared/schema.ts; then
    print_status "Categories table defined"
else
    print_error "Categories table missing from schema"
fi

# Test 4: Check latest features implementation
print_header "\n4. Validating Recent Updates..."
if test -f "client/src/pages/post-news.tsx"; then
    print_status "Post news page exists"
    # Check if simplified form (no tags/links)
    if ! grep -q "currentTag\|Badge.*tag" client/src/pages/post-news.tsx; then
        print_status "News form simplified (tags removed)"
    else
        print_error "News form still contains tags/links"
    fi
else
    print_error "Post news page missing"
fi

if ! test -f "client/src/pages/post-banner.tsx"; then
    print_status "Post banner page removed (cleanup complete)"
else
    print_error "Post banner page still exists"
fi

# Test 5: Check deployment script validity
print_header "\n5. Validating Deployment Script..."
if grep -q "NODE_ENV=production" deploy-vps.sh; then
    print_status "Production environment configured"
else
    print_error "Production environment not set in deployment"
fi

if grep -q "postgresql.*crypto_airdrop" deploy-vps.sh; then
    print_status "PostgreSQL setup configured"
else
    print_error "PostgreSQL setup missing from deployment"
fi

if grep -q "pm2.*ecosystem.config.cjs" deploy-vps.sh; then
    print_status "PM2 configuration included"
else
    print_error "PM2 configuration missing"
fi

if grep -q "nginx.*proxy_pass.*5000" deploy-vps.sh; then
    print_status "Nginx reverse proxy configured"
else
    print_error "Nginx configuration missing"
fi

# Test 6: Environment variables
print_header "\n6. Checking Environment Configuration..."
if grep -q "DATABASE_URL\|PGHOST\|PGPORT" deploy-vps.sh; then
    print_status "Database environment variables configured"
else
    print_error "Database environment variables missing"
fi

if grep -q "SESSION_SECRET" deploy-vps.sh; then
    print_status "Session secret generation included"
else
    print_error "Session secret generation missing"
fi

# Test 7: Security measures
print_header "\n7. Validating Security Configuration..."
if grep -q "ufw.*enable" deploy-vps.sh; then
    print_status "Firewall configuration included"
else
    print_error "Firewall configuration missing"
fi

if grep -q "add_header.*X-Frame-Options" deploy-vps.sh; then
    print_status "Security headers configured"
else
    print_error "Security headers missing"
fi

# Test 8: Management tools
print_header "\n8. Checking Management Tools..."
if grep -q "backup_database\|restore_database" deploy-vps.sh; then
    print_status "Backup/restore functionality included"
else
    print_error "Backup/restore functionality missing"
fi

if grep -q "health_check\|ssl_setup" deploy-vps.sh; then
    print_status "Health check and SSL setup included"
else
    print_error "Health check and SSL setup missing"
fi

# Test 9: Check if dependencies are installable
print_header "\n9. Testing Dependency Installation..."
if npm list >/dev/null 2>&1; then
    print_status "All dependencies are properly installed"
else
    print_warning "Some dependencies may need reinstallation"
fi

# Test 10: TypeScript compilation check
print_header "\n10. Testing TypeScript Compilation..."
if npx tsc --noEmit --skipLibCheck >/dev/null 2>&1; then
    print_status "TypeScript compilation successful"
else
    print_warning "TypeScript compilation has warnings (may not block deployment)"
fi

# Summary
print_header "\n================================================"
echo "Test Summary:"
echo "Passed: $PASSED_TESTS"
echo "Failed: $FAILED_TESTS"

if [ $FAILED_TESTS -eq 0 ]; then
    print_status "All tests passed! Deployment ready."
    echo ""
    echo "To deploy to VPS:"
    echo "1. Copy project to VPS: scp -r . user@your-vps:/tmp/crypto-airdrop"
    echo "2. SSH to VPS: ssh user@your-vps"
    echo "3. Run deployment: cd /tmp/crypto-airdrop && chmod +x deploy-vps.sh && ./deploy-vps.sh"
    exit 0
else
    print_error "Some tests failed. Please fix issues before deployment."
    exit 1
fi