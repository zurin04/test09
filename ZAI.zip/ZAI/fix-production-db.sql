-- Fix for production database - Add missing categories
-- Run this on your VPS to fix the foreign key constraint error

-- Insert missing categories if they don't exist
INSERT INTO categories (id, name, description, created_at) 
SELECT 1, 'DeFi', 'Decentralized Finance protocols and platforms', NOW()
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE id = 1);

INSERT INTO categories (id, name, description, created_at) 
SELECT 2, 'NFT', 'Non-Fungible Token projects and marketplaces', NOW()
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE id = 2);

INSERT INTO categories (id, name, description, created_at) 
SELECT 3, 'Gaming', 'Blockchain gaming and GameFi projects', NOW()
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE id = 3);

INSERT INTO categories (id, name, description, created_at) 
SELECT 4, 'News', 'Latest news and announcements', NOW()
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE id = 4);

INSERT INTO categories (id, name, description, created_at) 
SELECT 5, 'Layer 1', 'Layer 1 blockchain platforms and protocols', NOW()
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE id = 5);

INSERT INTO categories (id, name, description, created_at) 
SELECT 6, 'Layer 2', 'Layer 2 scaling solutions and side chains', NOW()
WHERE NOT EXISTS (SELECT 1 FROM categories WHERE id = 6);

-- Update the sequence to prevent conflicts
SELECT setval('categories_id_seq', (SELECT MAX(id) FROM categories) + 1);

-- Verify categories exist
SELECT id, name, description FROM categories ORDER BY id;